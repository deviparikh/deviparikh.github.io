
The Part Patch Dataset consists of about 0.3 million patches individually classified by human subjects into one of several human parts.

Collection of Part Patch Dataset:
-------------------------------

We had human subjects classify overlapping image patches into one of eight categories: head, torso, arm, hand, leg, foot, other-part-of-person, not-a-person. The patches were extracted from 50 INRIA and 100 PASCAL (2007) images, and were displayed in isolation at random so that no contextual information from the image was available to the subjects. We extracted patches from the original high-resolution as well as a low-resolution version of the images. Before extracting the patches, the high and low resolution images were transformed into one of the following representations: color (regular), grayscale and normalized gradient. This resulted in a total of 45,316 x 6 = 271,896 patches. Atleast 10 human subjects classified every patch into one of the 8 categories on Amazon's Mechanical Turk.
 
Similarly, we also had atleast 10 human subjects classify overlapping image sub-windows (a total of 6,218 x 6 = 37,308 windows) as containing a person or not (similar to 'root' detection). As with parts, the sub-windows were extracted from high and low resolution color, grayscale and normalized gradient images. 

For details about the size, resolution, etc. of the parts and roots, please refer to Section 4.2 of our paper (see citation below).

Contents:
-------------

/PartPatch/INRIA_50: Data collected on 50 random images from the INRIA dataset (http://pascal.inrialpes.fr/PartPatch/human/).

/PartPatch/PASCAL2007_100: Data collected on 100 random images containing people from the PASCAL 2007 dataset (http://pascallin.ecs.soton.ac.uk/challenges/VOC/voc2007/).

For <dataset> = INRIA_50 or PASCAL2007_100

/PartPatch/<dataset>/images_parts: The images from which patches were extracted for humans to classify into one of the part categories. The subdirectories within this directory correspond to the different image-processing operations applied to the images before extracting patches to show human subjects. These include color (regular) images, grayscale images and normalized gradient images, for both high and low resolution versions of the images. NOTE: All (high and low res) normalized gradient patches/windows were displayed to the human subjects after linearly normalizing them such that the highest normalized gradient pixel in the patch/window is 255.

/PartPatch/<dataset>/images_root: The images from which sub-windows were extracted for humans to classify as containing a person or not. The same image processing operations as described above were applied. NOTE: the part patches and root windows were extracted at different resolutions (see Section 4.2 of paper cited below). Hence the two different versions of the same images in images_root and images_part.

/PartPatch/<dataset>/groundtruth_person_bboxes: Groundtruth bounding boxes indicating the locations and extent of people in the images. The variable 'gt' is a an array of structures of length n corresponding to the n people present in an image. gt(n) contains two fields: tl (top-left corner of bounding box) and br (bottom right corner of the bounding box). The first number in both these fields corresponds to the row index, and the second to the column index in the image.

/PartPatch/<dataset>/human_parts_detection: 
All the patches extracted from the images, and the corresponding responses from at least 10 human subjects assigning these patches to parts. Each .mat file corresponds to one of the six feature extraction schemes. The .mat file loads a variable 'block' that is an array of structures. Each structure corresponds to one patch. It contains the following fields:
tl: similar to the groundtruth variable ('gt'), it indicates the row and column image-indices of the top-left corner of the patch
br: indicates the row and column image-indices of the bottom-right corner of the patch
imname: the image from which the patch was extracted
imid: the index of the image (1 to 50 for iNRIA_50, 1 to 100 for PASCAL2007_100)
responses: the response of at least 10 human subjects to this patch. The responses are integers from 0 to 8, which indicate the following. 0: no response, 1: head, 2: torso, 3: arm, 4: hand, 5: leg, 6: foot, 7: other person-part, 8: not a person.

/PartPatch/<dataset>/human_root_detection: All the sub-windows extracted from the images, and the corresponding responses from at least 10 human subjects classifying these windows as containing a person or not. The format of the variables is similar to those in /PartPatch/<dataset>/human_parts_detection, except that the response values are 0: no response, 9: person, 10: not a person.

Citation:
-----------

If you use the Part Patch dataset, please cite the following paper:
Devi Parikh and Larry Zitnick. Finding the Weakest Link in Person Detectors. IEEE Conference on Computer Vision and Pattern Recognition (CVPR), 2011.

Contact:
-----------

If you have any questions about the data, please contact Devi Parikh (dparikh@ttic.edu).