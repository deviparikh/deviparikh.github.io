g++ ClipArtRender_stdin.cpp -o render_online
