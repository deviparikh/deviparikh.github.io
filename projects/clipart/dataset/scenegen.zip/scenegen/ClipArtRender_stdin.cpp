// ClipArtRender.cpp : Defines the entry point for the console application.

//


#define _CRT_SECURE_NO_WARNINGS


#include <iostream>

#include <fstream>

#include <string>

//Because of this you can't run in windows
#include <unistd.h>

using namespace std;


#include "ClipArtRender_stdin.h"





#ifndef max

#define max(a,b)            (((a) > (b)) ? (a) : (b))

#endif



#ifndef min

#define min(a,b)            (((a) < (b)) ? (a) : (b))

#endif





/*

	prefix.push('s');

	prefix.push('p');

	prefix.push('hb0');

	prefix.push('hb1');

	prefix.push('a');

	prefix.push('c');

	prefix.push('e');

	prefix.push('t');



	typeTotalCt.push(8);

	typeTotalCt.push(10);

	typeTotalCt.push(35);

	typeTotalCt.push(35);

	typeTotalCt.push(6);

	typeTotalCt.push(10);

	typeTotalCt.push(7);

	typeTotalCt.push(15);

*/



#ifndef max

#define max(a,b)            (((a) > (b)) ? (a) : (b))

#endif



#ifndef min

#define min(a,b)            (((a) < (b)) ? (a) : (b))

#endif



// 0	0	0	1

// 0	2	1	3

// 0	2	2	1

// 1	0	3	4

// 1	0	4	5

// 1	2	4	5

// 1	5	5	6

// 2	2	3	4

// 2	0	6	1

// 2	7	7	8

// 3	2	8	1

// 3	0	9	8

// 3	0	10	9



void CClipArt::RenderScene(std::vector<int> clipArtTypeIdx, std::vector<int> clipArtObjectIdx, std::vector<int> clipArtX, std::vector<int> clipArtY, std::vector<int> clipArtZ, 

						   std::vector<int> clipArtFlip, vt::CRGBAImg &outImg)

{
	return;
	int i, j, k, r, c;

	int ct = clipArtTypeIdx.size();

	vt::CRGBAImg img;

	vt::wstring wstr2(320);



	char (*prefix)[256] = new char [m_NumTypes][256];



	sprintf(prefix[0], "C:\\data\\Clipart\\Sentence2Scene\\pngs\\s");

	sprintf(prefix[1], "C:\\data\\Clipart\\Sentence2Scene\\pngs\\p");

	sprintf(prefix[2], "C:\\data\\Clipart\\Sentence2Scene\\pngs\\hb0");

	sprintf(prefix[3], "C:\\data\\Clipart\\Sentence2Scene\\pngs\\hb1");

	sprintf(prefix[4], "C:\\data\\Clipart\\Sentence2Scene\\pngs\\a");

	sprintf(prefix[5], "C:\\data\\Clipart\\Sentence2Scene\\pngs\\c");

	sprintf(prefix[6], "C:\\data\\Clipart\\Sentence2Scene\\pngs\\e");

	sprintf(prefix[7], "C:\\data\\Clipart\\Sentence2Scene\\pngs\\t");



	wstr2.format(L"C:\\data\\Clipart\\Sentence2Scene\\pngs\\background.png");

	//VtLoadImage(wstr2, outImg);



	// Make sure we get the depth ordering correct

	for (j = 2; j >= 0; j--) {

		for(k=0;k<m_NumInstanceObj;k++)

		for (i = 0; i < ct; i++) {

			int idx0 = m_MapInstance[clipArtTypeIdx[i]][clipArtObjectIdx[i]];

		    if (k == idx0 && clipArtZ[i] == j && clipArtTypeIdx[i] == 0) {



				//printf("Loading %s_%d.png\n", prefix[clipArtTypeIdx[i]], clipArtObjectIdx[i]);

				wstr2.format(L"%S_%d.png", prefix[clipArtTypeIdx[i]], clipArtObjectIdx[i]);

				//VtLoadImage(wstr2, img);

				if(img.imgx == 0)

				{

					int w = m_ClipArtW[clipArtTypeIdx[i]][clipArtObjectIdx[i]][clipArtZ[i]];

					int h = m_ClipArtH[clipArtTypeIdx[i]][clipArtObjectIdx[i]][clipArtZ[i]];



					int rowOffset = -h / 2;

					int colOffset = -w / 2;



					//printf("%d %d\n", w, h);



					for(r=0;r<h;r++)

						for(c=0;c<w;c++)

					{

						int x = clipArtX[i] + c + colOffset;

						int y = clipArtY[i] + r + rowOffset;

						vt::RGBAPix pix = img.Pix(c + m_ClipArtC[clipArtTypeIdx[i]][clipArtObjectIdx[i]][clipArtZ[i] * 2 + clipArtFlip[i]], r);

					//	vt::RGBAPix pix = img.Pix(c + clipArtC[i][clipArtZ[i] * 2 + clipArtFlip[i]], r);



						float alpha = (float) pix.a/255,f;

							

						if(x >= 0 && x < outImg.Width() && y >= 0 && y < outImg.Height())

						{

							outImg.Pix(x, y).r = (int) ((1.f - alpha)*(float) outImg.Pix(x, y).r + alpha*(float) pix.r);

							outImg.Pix(x, y).g = (int) ((1.f - alpha)*(float) outImg.Pix(x, y).g + alpha*(float) pix.g);

							outImg.Pix(x, y).b = (int) ((1.f - alpha)*(float) outImg.Pix(x, y).b + alpha*(float) pix.b);

						}

					}

				}

		    }

		}

	}



	// Make sure we get the depth ordering correct

	for (j = 2; j >= 0; j--) {

		for(k=0;k<m_NumInstanceObj;k++)

		for (i = 0; i < ct; i++) {

			int idx0 = m_MapInstance[clipArtTypeIdx[i]][clipArtObjectIdx[i]];

		    if (idx0 == k && clipArtX[i] >= 0 && clipArtZ[i] == j && clipArtTypeIdx[i] != 0) {

					

			//	printf("Loading images\\%s\n", imgNames[i]);

				wstr2.format(L"%S_%d.png", prefix[clipArtTypeIdx[i]], clipArtObjectIdx[i]);

			//	VtLoadImage(wstr2, img);

				if(img.imgx == 0)

				{					

					int w = m_ClipArtW[clipArtTypeIdx[i]][clipArtObjectIdx[i]][clipArtZ[i]];

					int h = m_ClipArtH[clipArtTypeIdx[i]][clipArtObjectIdx[i]][clipArtZ[i]];



					int rowOffset = -h / 2;

					int colOffset = -w / 2;



					for(r=0;r<h;r++)

						for(c=0;c<w;c++)

					{

						int x = clipArtX[i] + c + colOffset;

						int y = clipArtY[i] + r + rowOffset;

						vt::RGBAPix pix = img.Pix(c + m_ClipArtC[clipArtTypeIdx[i]][clipArtObjectIdx[i]][clipArtZ[i] * 2 + clipArtFlip[i]], r);



						float alpha = (float) pix.a/255,f;

							

						if(x >= 0 && x < outImg.Width() && y >= 0 && y < outImg.Height())

						{

							outImg.Pix(x, y).r = (int) ((1.f - alpha)*(float) outImg.Pix(x, y).r + alpha*(float) pix.r);

							outImg.Pix(x, y).g = (int) ((1.f - alpha)*(float) outImg.Pix(x, y).g + alpha*(float) pix.g);

							outImg.Pix(x, y).b = (int) ((1.f - alpha)*(float) outImg.Pix(x, y).b + alpha*(float) pix.b);

						}

					}

				}

		    }

		}

	}



	delete [] prefix;



//	wstr2.format(L"%S_%d_%d.png", baseName, idx/hitSize, idx%hitSize);

//	VtSaveImage(wstr2, outImg);

}


void CClipArt::DumpScene(std::vector<int> clipArtTypeIdx, std::vector<int> clipArtObjectIdx, std::vector<int> clipArtX, std::vector<int> clipArtY, std::vector<int> clipArtZ, 

						   std::vector<int> clipArtFlip, char* dumpster, int id)

{


	int i, j, k;

	char *out;

	char name[1024];

	int notUsed = -10000;



	char (*prefix)[256] = new char [m_NumTypes][256];

	sprintf(prefix[0], "s");

	sprintf(prefix[1], "p");

	sprintf(prefix[2], "hb0");

	sprintf(prefix[3], "hb1");

	sprintf(prefix[4], "a");

	sprintf(prefix[5], "c");

	sprintf(prefix[6], "e");

	sprintf(prefix[7], "t");




	sprintf(dumpster, "%d\t%d\n", id, int(clipArtTypeIdx.size()));



	for(j=0;j<clipArtTypeIdx.size();j++)

	{

		if(clipArtX[j] > notUsed)

		{

			sprintf(dumpster+strlen(dumpster), "%s_%ds.png\t%d\t%d\t", prefix[clipArtTypeIdx[j]], clipArtObjectIdx[j], clipArtTypeIdx[j], clipArtObjectIdx[j]);

			sprintf(dumpster+strlen(dumpster), "%d\t%d\t\%d\t%d\n", clipArtX[j], clipArtY[j], clipArtZ[j], clipArtFlip[j]);

		}

	}





}






float CClipArt::ScoreScene(std::vector<int> clipArtTypeIdx, std::vector<int> clipArtObjectIdx, std::vector<int> clipArtX, std::vector<int> clipArtY, std::vector<int> clipArtZ, 

						   std::vector<int> clipArtFlip, float *desiredAttributes)

{

	int i, j, k;

	int ct = clipArtTypeIdx.size();

	float score = 0.f;

	float maxLog = -log(0.001f);

	float *curAttributes = new float [m_NumInstanceObj*m_NumAttributes];



	ComputeAttributes(clipArtObjectIdx, clipArtTypeIdx, clipArtX, clipArtY, clipArtZ, clipArtFlip, ct, curAttributes);



	// Unary potentials

	for(i=0;i<m_NumInstanceObj;i++)

	{

		//Occurrence

		float prob;



		prob = desiredAttributes[i*m_NumAttributes]*curAttributes[i*m_NumAttributes] + (1.f - desiredAttributes[i*m_NumAttributes])*(1.f - curAttributes[i*m_NumAttributes]);

		score += min(maxLog, -log(prob));



		if(desiredAttributes[i*m_NumAttributes] == 1.f && curAttributes[i*m_NumAttributes] == 0.f)

			score += 10000.f;


		//Attribute
		if(i == 18 || i == 19)

		{

			for(j=0;j<m_NumPersonAttrs;j++)

			{

				prob = desiredAttributes[i*m_NumAttributes + m_ExpressionIdx + j]*curAttributes[i*m_NumAttributes + m_ExpressionIdx + j] + 

					(1.f - desiredAttributes[i*m_NumAttributes + m_ExpressionIdx + j])*(1.f - curAttributes[i*m_NumAttributes + m_ExpressionIdx + j]);

				score += min(maxLog, -log(prob));

			}

		}



		//Absolute Spatial

		prob = 0.f;

		for(j=0;j<NUM_GM_SPAT*m_NumDepth;j++)

		{

			//prob += min(desiredAttributes[i*m_NumAttributes + m_AbsoluteSpatialIdx + j], curAttributes[i*m_NumAttributes + m_AbsoluteSpatialIdx + j]);
			//prob = max(prob,desiredAttributes[i*m_NumAttributes + m_AbsoluteSpatialIdx + j]*curAttributes[i*m_NumAttributes + m_AbsoluteSpatialIdx + j]);
			prob += (desiredAttributes[i*m_NumAttributes + m_AbsoluteSpatialIdx + j] * curAttributes[i*m_NumAttributes + m_AbsoluteSpatialIdx + j]); 

		}

	//	printf("%f s ", prob);

		score += min(maxLog, -log(prob));

	}



	// Binary potentials
 
	for(i=0;i<ct;i++)

		if(clipArtX[i] >= 0)

		for(j=0;j<ct;j++)

			if(i != j && clipArtX[j] >= 0)

	{

		int idx0 = m_MapInstance[clipArtTypeIdx[i]][clipArtObjectIdx[i]];

		int idx1 = m_MapInstance[clipArtTypeIdx[j]][clipArtObjectIdx[j]];



		// Co-occurrence

		float prob = 0.f;

	//	prob += desiredAttributes[idx0*m_NumAttributes + m_CoOccurrenceIdx + idx1]*curAttributes[idx0*m_NumAttributes + m_CoOccurrenceIdx + idx1];

	//	prob += (1.f - desiredAttributes[idx0*m_NumAttributes + m_CoOccurrenceIdx + idx1])*(1.f - curAttributes[idx0*m_NumAttributes + m_CoOccurrenceIdx + idx1]);

	//	score -= log(max(minProb, prob));





		//Relative Spatial Flip

		prob = 0.f;

		for(k=0;k<NUM_GM_REL;k++)

		{

			//prob += (desiredAttributes[idx0*m_NumAttributes + m_RelativeSpatialFlipIdx + idx1*NUM_GM_REL + k])*(curAttributes[idx0*m_NumAttributes + m_RelativeSpatialFlipIdx + idx1*NUM_GM_REL + k]);
			prob = max(prob,desiredAttributes[idx0*m_NumAttributes + m_RelativeSpatialFlipIdx + idx1*NUM_GM_REL + k]*curAttributes[idx0*m_NumAttributes + m_RelativeSpatialFlipIdx + idx1*NUM_GM_REL + k]);

		//	prob += (desiredAttributes[idx0*m_NumAttributes + m_RelativeSpatialFlipIdx + idx1*NUM_GM_REL + k])*(curAttributes[idx0*m_NumAttributes + m_RelativeSpatialFlipIdx + idx1*NUM_GM_REL + k]);

		//	prob += (1.f - desiredAttributes[idx0*m_NumAttributes + m_RelativeSpatialFlipIdx + idx1*NUM_GM_REL + k])*(1.f - curAttributes[idx0*m_NumAttributes + m_RelativeSpatialFlipIdx + idx1*NUM_GM_REL + k]);

		}

		score += min(maxLog, -log(prob));

		

		// Relative Depth

		prob = 0.f;

		for(k=0;k<3;k++)

		{

			prob += (desiredAttributes[idx0*m_NumAttributes + m_RelativeDepthIdx + idx1*3 + k])*(curAttributes[idx0*m_NumAttributes + m_RelativeDepthIdx + idx1*3 + k]);

		//	prob += (desiredAttributes[idx0*m_NumAttributes + m_RelativeDepthIdx + idx1*3 + k])*(curAttributes[idx0*m_NumAttributes + m_RelativeDepthIdx + idx1*3 + k]);

		//	prob += (1.f - desiredAttributes[idx0*m_NumAttributes + m_RelativeDepthIdx + idx1*3 + k])*(1.f - curAttributes[idx0*m_NumAttributes + m_RelativeDepthIdx + idx1*3 + k]);

		}

		score += min(maxLog, -log(prob));

		/*

		if(idx0 == 18 || idx0 == 19)

		{

		

			// Relative Head

			prob = 0.f;

			for(k=0;k<m_NumInstanceObj;k++)

			{

			//	prob += min(desiredAttributes[idx0*m_NumAttributes + m_HeadIdx + k], curAttributes[idx0*m_NumAttributes + m_HeadIdx + k]);

			//	prob += (desiredAttributes[idx0*m_NumAttributes + m_HeadIdx + k]*curAttributes[idx0*m_NumAttributes + m_HeadIdx + k]);

			//	prob += (1.f - desiredAttributes[idx0*m_NumAttributes + m_HeadIdx + k])*(1.f - curAttributes[idx0*m_NumAttributes + m_HeadIdx + k]);

			}

			//score -= log(max(0.01f, prob));

		

			// Relative Hand

			prob = 0.f;

			for(k=0;k<m_NumInstanceObj;k++)

			{

			//	prob += (desiredAttributes[idx0*m_NumAttributes + m_HandIdx + k]*curAttributes[idx0*m_NumAttributes + m_HandIdx + k]);

			//	prob += (1.f - desiredAttributes[idx0*m_NumAttributes + m_HandIdx + k])*(1.f - curAttributes[idx0*m_NumAttributes + m_HandIdx + k]);

			}

			//score -= log(max(0.01f, prob));

		}

		*/

		

	}



	delete [] curAttributes;



	return score;





}



void CClipArt::ComputePDFs(float *attributes)

{

	int i, j, k, l, r, c;

	int sf = 10;



	m_PDFPrior.resize(m_NumDepth*m_NumInstanceObj);

	m_PDFPost.resize(m_NumInstanceObj*m_NumInstanceObj);

	float probGMM[max(NUM_GM_REL, NUM_GM_SPAT)];

	int px = 0;

	int py = 0;

	int pz = 0;



	vt::CRGBAImg debugImg;

	debugImg.Create(CANVAS_WIDTH/sf, CANVAS_HEIGHT/sf);



	for(i=0;i<m_NumDepth;i++)

		for(j=0;j<m_NumInstanceObj;j++)

	{

		m_PDFPrior[i*m_NumInstanceObj + j].Create(CANVAS_WIDTH/sf, CANVAS_HEIGHT/sf);



		float denom = 0.f;

		for(r=0;r<CANVAS_HEIGHT/sf;r++)

			for(c=0;c<CANVAS_WIDTH/sf;c++)

			{

				float sum = 0.f;

				for(k=0;k<NUM_GM_SPAT;k++)

					probGMM[k] = 0.f;



				float posit[2];

				posit[0] = (float) (c*sf);

				posit[1] = (float) (r*sf);

				ComputeGMMProbs(posit, m_GMM_mean_Spat[i], m_GMM_std_Spat[i], probGMM, NUM_GM_SPAT);



				for(k=0;k<NUM_GM_SPAT;k++)

					sum += attributes[j*m_NumAttributes + m_AbsoluteSpatialIdx + i*NUM_GM_SPAT + k]*probGMM[k];



				denom += sum;



				m_PDFPrior[i*m_NumInstanceObj + j].Pix(c, r) = sum;

			}



		for(r=0;r<CANVAS_HEIGHT/sf;r++)

			for(c=0;c<CANVAS_WIDTH/sf;c++)

				m_PDFPrior[i*m_NumInstanceObj + j].Pix(c, r) /= denom;

	}



	for(i=0;i<m_NumInstanceObj;i++)

		for(j=0;j<m_NumInstanceObj;j++)

			if(i != j)

				m_PDFPost[i*m_NumInstanceObj + j].Create(2*CANVAS_WIDTH/sf, 2*CANVAS_HEIGHT/sf);





	for(r=0;r<2*CANVAS_HEIGHT/sf;r++)

		for(c=0;c<2*CANVAS_WIDTH/sf;c++)

		{

			for(l=0;l<NUM_GM_REL;l++)

				probGMM[l] = 0.f;



			float posit[2];

			posit[0] = (float) (c*sf - CANVAS_WIDTH);

			posit[1] = (float) (r*sf - CANVAS_HEIGHT);

			ComputeGMMProbs(posit, m_GMM_mean_RelFlip, m_GMM_std_RelFlip, probGMM, NUM_GM_REL);



			for(i=0;i<m_NumInstanceObj;i++)

				for(j=0;j<m_NumInstanceObj;j++)

					if(i != j)

					{

						float sum = 0.f;

						for(l=0;l<NUM_GM_REL;l++)

							sum += attributes[i*m_NumAttributes + m_RelativeSpatialFlipIdx + j*NUM_GM_REL + l]*probGMM[l];

				



						m_PDFPost[i*m_NumInstanceObj + j].Pix(c, r) = sum;

					}

		}

}





float CClipArt::GenerateScene(float *attributes, vt::CRGBAImg &outImg, char* dumpster, int scene_id)

{

	int maxProb = 0.f;

	int i, j, k, l, r, c;

	int numIter = 1000;

	float minScore = 1000000.f;





	std::vector<int> clipArtTypeIdxBest;

	std::vector<int> clipArtObjectIdxBest;

	std::vector<int> clipArtXBest;

	std::vector<int> clipArtYBest;

	std::vector<int> clipArtZBest;

	std::vector<int> clipArtFlipBest;



	clipArtTypeIdxBest.resize(0);

	clipArtObjectIdxBest.resize(0);

	clipArtXBest.resize(0);

	clipArtYBest.resize(0);

	clipArtZBest.resize(0);

	clipArtFlipBest.resize(0);



	std::vector<int> clipArtTypeIdxPrev;

	std::vector<int> clipArtObjectIdxPrev;

	std::vector<int> clipArtXPrev;

	std::vector<int> clipArtYPrev;

	std::vector<int> clipArtZPrev;

	std::vector<int> clipArtFlipPrev;



	clipArtTypeIdxPrev.resize(0);

	clipArtObjectIdxPrev.resize(0);

	clipArtXPrev.resize(0);

	clipArtYPrev.resize(0);

	clipArtZPrev.resize(0);

	clipArtFlipPrev.resize(0);



	std::vector<int> clipArtTypeIdx;

	std::vector<int> clipArtObjectIdx;

	std::vector<int> clipArtX;

	std::vector<int> clipArtY;

	std::vector<int> clipArtZ;

	std::vector<int> clipArtFlip;



	int sf = 10;

	vt::Matrix pdf;

	pdf.Create(CANVAS_WIDTH/sf, CANVAS_HEIGHT/sf);

	float probGMM[max(NUM_GM_REL, NUM_GM_SPAT)];

	int px = 0;

	int py = 0;

	int pz = 0;



	vt::CRGBAImg debugImg;

	debugImg.Create(CANVAS_WIDTH/sf, CANVAS_HEIGHT/sf);



	vt::CRGBAImg oImg;

	oImg.Create(10*CANVAS_WIDTH/sf, 6*CANVAS_HEIGHT/sf);

	oImg.Clear();



	for(i=0;i<numIter;i++)

	{

		if(i%100 == 0)

			printf(".");



		int numVisible = 0;



		clipArtTypeIdx.resize(0);

		clipArtObjectIdx.resize(0);

		clipArtX.resize(0);

		clipArtY.resize(0);

		clipArtZ.resize(0);

		clipArtFlip.resize(0);



		float prob = (float) rand()/(float) RAND_MAX;

		j = rand()%m_NumInstanceObj;

		bool notgood = true;



		while(notgood)

		{

			if(prob < attributes[j*m_NumAttributes])

				notgood = false;

			else

			{

				for(k=0;k<clipArtTypeIdxPrev.size();k++)

					if(j == m_MapInstance[clipArtTypeIdxPrev[k]][clipArtObjectIdxPrev[k]])

						notgood = false;



				if(notgood)

				{

					prob = (float) rand()/(float) RAND_MAX;

					j = rand()%m_NumInstanceObj;

				}

			}

		}



		for(k=0;k<clipArtTypeIdxPrev.size();k++)

		{

			if(j != m_MapInstance[clipArtTypeIdxPrev[k]][clipArtObjectIdxPrev[k]])

			{

				clipArtTypeIdx.push_back(clipArtTypeIdxPrev[k]);

				clipArtObjectIdx.push_back(clipArtObjectIdxPrev[k]);

				clipArtX.push_back(clipArtXPrev[k]);

				clipArtY.push_back(clipArtYPrev[k]);

				clipArtZ.push_back(clipArtZPrev[k]);

				clipArtFlip.push_back(clipArtFlipPrev[k]);



			}

		}



	//	for(j=0;j<m_NumInstanceObj;j++)

		{





			if(prob < attributes[j*m_NumAttributes])

			{

				float denom = 0.f;

				float sum = 0.f;

				int typeIdx = m_MapType[j];

				int objectIdx;



				clipArtTypeIdx.push_back(m_MapType[j]);



				if(m_MapType[j] == 2 || m_MapType[j] == 3)

				{

					prob = (float) rand()/(float) RAND_MAX;



					int expression = 0;

					int pose = 0;

					/*

					sum = 0.f;

					while(prob >= sum && expression < m_NumExpressions)

					{

						sum += attributes[j*m_NumAttributes + m_ExpressionIdx + expression];

						expression++;

					}

					expression--;



					prob = (float) rand()/(float) RAND_MAX;

					sum = 0.f;

					while(prob >= sum && pose < m_NumPoses)

					{

						sum += attributes[j*m_NumAttributes + m_PoseIdx + pose];

						pose++;

					}

					pose--;

					*/



					prob = 0;

					for(k=0;k<m_NumExpressions;k++)

						if(prob < attributes[j*m_NumAttributes + m_ExpressionIdx + k])

						{

							prob = attributes[j*m_NumAttributes + m_ExpressionIdx + k];

							expression = k;

						}



					prob = 0;

					for(k=0;k<m_NumPoses;k++)

						if(prob < attributes[j*m_NumAttributes + m_PoseIdx + k])

						{

							prob = attributes[j*m_NumAttributes + m_PoseIdx + k];

							pose = k;

						}



					clipArtObjectIdx.push_back(pose*m_NumExpressions + expression);

					objectIdx = pose*m_NumExpressions + expression;

				}

				else

				{

					clipArtObjectIdx.push_back(m_MapObject[j]);

					objectIdx = m_MapObject[j];

				}



				

			/*	if(j == 19)

				{

					//printf("%d %d %f : ", c, r);

					debugImg.Pix(c, r).g = min(255, debugImg.Pix(c, r).g + 80);

					debugImg.Pix(c, r).b = min(255, debugImg.Pix(c, r).b + 80);

				//	debugImg.Pix(c, r).g = 0;

				//	debugImg.Pix(c, r).b = 0;

				}

				*/

				float probDepth[3];

				probDepth[0] = 0.f;

				probDepth[1] = 0.f;

				probDepth[2] = 0.f;

				

				for(k=0;k<clipArtTypeIdxPrev.size();k++)

				{

					int idx0 = m_MapInstance[clipArtTypeIdxPrev[k]][clipArtObjectIdxPrev[k]];

					

					if(idx0 != j && clipArtTypeIdxPrev[k] != 5)

					{

						int z0;



						z0 = clipArtZPrev[k];

						int m;



						

						for(l=0;l<3;l++)

						{

							m = 0;



							if(l > z0)

								m = 0;

							if(l == z0)

								m = 1;

							if(l < z0)

								m = 2;



							probDepth[l] += attributes[j*m_NumAttributes + m_RelativeDepthIdx + idx0*3 + m];

						}

					}

				}

				

			//	probDepth[0] = attributes[j*m_NumAttributes + absoluteDepthIdx + 0];

			//	probDepth[1] = attributes[j*m_NumAttributes + absoluteDepthIdx + 1];

			//	probDepth[2] = attributes[j*m_NumAttributes + absoluteDepthIdx + 2];





				denom = 0.0000001f;

				for(k=0;k<3;k++)

					denom += probDepth[k];

				for(k=0;k<3;k++)

				{

					probDepth[k] /= denom;

				}





				//printf("%d %f %f %f\n", j, probDepth[0], probDepth[1], probDepth[2]); 



				prob = (float) rand()/(float) RAND_MAX;

				int depth = 0;

				sum = 0.f;

				while(prob >= sum && depth < m_NumDepth)

				{

					sum += probDepth[depth];

					depth++;

				}

				depth--;

				clipArtZ.push_back(depth);





				m_PDFPrior[depth*m_NumInstanceObj + j].CopyTo(pdf);

				

				for(k=0;k<clipArtTypeIdxPrev.size();k++)

				{

					int idx0 = m_MapInstance[clipArtTypeIdxPrev[k]][clipArtObjectIdxPrev[k]];



					if(idx0 != j && clipArtTypeIdxPrev[k] != 5)

					{

						int x0, y0, f0;



						x0 = clipArtXPrev[k];

						y0 = clipArtYPrev[k];

						f0 = clipArtFlipPrev[k];

						

						denom = 0.00000001f;



						for(r=0;r<CANVAS_HEIGHT/sf;r++)

							for(c=0;c<CANVAS_WIDTH/sf;c++)

							{

								int x1 = (c*sf - x0)/sf;

								int y1 = (r*sf - y0)/sf;



								if(f0 == 1)

									x1 = -x1;



								x1 += CANVAS_WIDTH/sf;

								y1 += CANVAS_HEIGHT/sf;



								pdf.Pix(c, r) *= m_PDFPost[idx0*m_NumInstanceObj + j].Pix(x1, y1) + 0.001f;

								denom += pdf.Pix(c, r);

							}



						for(r=0;r<CANVAS_HEIGHT/sf;r++)

							for(c=0;c<CANVAS_WIDTH/sf;c++)

								pdf.Pix(c, r) /= denom;



					}

				}



				int border = 150;

				int rs = min(border, m_ClipArtH[typeIdx][objectIdx][depth]/2)/sf; 

				int re = max(CANVAS_HEIGHT - border, CANVAS_HEIGHT - m_ClipArtH[typeIdx][objectIdx][depth]/2)/sf; 

				int cs = min(border, m_ClipArtW[typeIdx][objectIdx][depth]/2)/sf; 

				int ce = max(CANVAS_WIDTH - border, CANVAS_WIDTH - m_ClipArtW[typeIdx][objectIdx][depth]/2)/sf; 



				for(r=0;r<rs;r++)

					for(c=0;c<CANVAS_WIDTH/sf;c++)

						pdf.Pix(c, r) = 0.f;



				for(r=re;r<CANVAS_HEIGHT/sf;r++)

					for(c=0;c<CANVAS_WIDTH/sf;c++)

						pdf.Pix(c, r) = 0.f;



				for(r=0;r<CANVAS_HEIGHT/sf;r++)

					for(c=0;c<cs;c++)

						pdf.Pix(c, r) = 0.f;



				for(r=0;r<CANVAS_HEIGHT/sf;r++)

					for(c=ce;c<CANVAS_WIDTH/sf;c++)

						pdf.Pix(c, r) = 0.f;

						

				denom = 0.0000001f;

				for(r=0;r<CANVAS_HEIGHT/sf;r++)

					for(c=0;c<CANVAS_WIDTH/sf;c++)

						denom += pdf.Pix(c, r);



				for(r=0;r<CANVAS_HEIGHT/sf;r++)

					for(c=0;c<CANVAS_WIDTH/sf;c++)

						pdf.Pix(c, r) = pdf.Pix(c, r)/denom;



				//printf("%f ", denom);

				

					

				c = r = 0;

				sum = 0.f;

				prob = (float) rand()/(float) RAND_MAX;

				while(prob >= sum && r < CANVAS_HEIGHT/sf)

				{

					sum += pdf.Pix(c, r);

					c++;

					if(c == CANVAS_WIDTH/sf)

					{

						c = 0;

						r++;

					}

				}

				if(c > 0)

					c--;

				else

					r--;



				int x1 = c*sf;

				int y1 = r*sf;



				float maxval = 0.f;

				for(r=0;r<CANVAS_HEIGHT/sf;r++)

					for(c=0;c<CANVAS_WIDTH/sf;c++)

						if(maxval < pdf.Pix(c, r))

						{

							x1 = c*sf;

							y1 = r*sf;

							maxval = pdf.Pix(c, r);

						}





				/*if(j == 29)

				{

					int ro = (j/10)*(CANVAS_HEIGHT/sf);

					int co = (j%10)*(CANVAS_WIDTH/sf);

				//	vt::CRGBImg oImg;

				//	oImg.Create(CANVAS_WIDTH/sf, CANVAS_HEIGHT/sf);

					for(r=0;r<CANVAS_HEIGHT/sf;r++)

						for(c=0;c<CANVAS_WIDTH/sf;c++)

						{

							oImg.Pix(c + co, r + ro).r = (int) (15500.f*pdf.Pix(c, r));

							oImg.Pix(c + co, r + ro).g = (int) (15500.f*pdf.Pix(c, r));

							oImg.Pix(c + co, r + ro).b = 80;//(int) (15500.f*pdf.Pix(c, r));

						}





					vt::RGBAPix clr;

					clr.r = 255;

					clr.g = 0;

					clr.b = 0;

					vt::VtDrawCircle(oImg, px + co, py + ro, 5.f, (byte *) &clr, NULL);



					clr.r = 0;

					clr.g = 255;

					clr.b = 0;

					vt::VtDrawCircle(oImg, x1/sf + co, y1/sf + ro, 2.f, (byte *) &clr, NULL);



					clr.r = 0;

					clr.g = 0;

					clr.b = 255;

					vt::VtDrawCircle(oImg, hx/sf + co, hy/sf + ro, 3.f, (byte *) &clr, NULL);



					vt::wstring wstr2(320);

					wstr2.format(L"%Sdebug_S.png", m_BaseName);

					VtSaveImage(wstr2, oImg);



				//	printf("%d %d   %f %f %f\n", depth, pz, probDepth[0], probDepth[1], probDepth[2]);



				}

				*/

				clipArtX.push_back(x1);

				clipArtY.push_back(y1);

			

				float probFlip[2];

				probFlip[0] = 1.f;

				probFlip[1] = 1.f;



				for(k=0;k<clipArtTypeIdxPrev.size();k++)

				{

					int idx0 = m_MapInstance[clipArtTypeIdxPrev[k]][clipArtObjectIdxPrev[k]];

					

					if(idx0 != j && clipArtTypeIdxPrev[k] != 5)

					{

						int x0, y0, f0;



						x0 = clipArtXPrev[k];

						y0 = clipArtYPrev[k];

						f0 = clipArtFlipPrev[k];

						int m;



						for(m=0;m<2;m++)

						{

							float sum = 0.f;

							for(l=0;l<NUM_GM_REL;l++)

								probGMM[l] = 0.f;



							float posit[2];

							ComputeRelativePosition(x1, x0, y1, y0, m, posit, 1);

							ComputeGMMProbs(posit, m_GMM_mean_RelFlip, m_GMM_std_RelFlip, probGMM, NUM_GM_REL);



							for(l=0;l<NUM_GM_REL;l++)

								sum += attributes[j*m_NumAttributes + m_RelativeSpatialFlipIdx + idx0*NUM_GM_REL + l]*probGMM[l];



							probFlip[m] *= 100.f*sum + 0.1f;

						}

					}

				}



				denom = 0.f;

				denom = probFlip[0] + probFlip[1] + 0.0000001;

				prob = (float) rand()/(float) RAND_MAX;

				if(prob < probFlip[0]/denom)

					clipArtFlip.push_back(0);

				else

					clipArtFlip.push_back(1);



				numVisible++;

			}

		}



		int size = clipArtTypeIdx.size();



		int boyIdx = -1;

		int girlIdx = -1;



		for(j=0;j<size;j++)

		{

			if(clipArtTypeIdx[j] == 2)

				boyIdx = j;

			if(clipArtTypeIdx[j] == 3)

				girlIdx = j;

		}

		

		if(boyIdx >= 0 || girlIdx >= 0)

		for(j=0;j<size;j++)

		{

			if(clipArtTypeIdx[j] == 5)

			{

				float bVal = -1.f;

				float gVal = -1.f;



				if(boyIdx >= 0)

					bVal = attributes[m_MapInstance[clipArtTypeIdx[boyIdx]][clipArtObjectIdx[boyIdx]]*m_NumAttributes + m_ClothingIdx + clipArtObjectIdx[j]];

				if(girlIdx >= 0)

					gVal = attributes[m_MapInstance[clipArtTypeIdx[girlIdx]][clipArtObjectIdx[girlIdx]]*m_NumAttributes + m_ClothingIdx + clipArtObjectIdx[j]];



				if(bVal > gVal)

				{

					int hx, hy;

					ComputeHeadPosition(clipArtTypeIdx[boyIdx], clipArtObjectIdx[boyIdx], clipArtX[boyIdx], 

						clipArtY[boyIdx], clipArtZ[boyIdx], clipArtFlip[boyIdx], clipArtObjectIdx[j], hx, hy);



					clipArtX[j] = hx;

					clipArtY[j] = hy;

					clipArtZ[j] = clipArtZ[boyIdx];

					clipArtFlip[j] = clipArtFlip[boyIdx];

				}

				else

				{

					int hx, hy;

					ComputeHeadPosition(clipArtTypeIdx[girlIdx], clipArtObjectIdx[girlIdx], clipArtX[girlIdx], 

						clipArtY[girlIdx], clipArtZ[girlIdx], clipArtFlip[girlIdx], clipArtObjectIdx[j], hx, hy);



					clipArtX[j] = hx;

					clipArtY[j] = hy;

					clipArtZ[j] = clipArtZ[girlIdx];

					clipArtFlip[j] = clipArtFlip[girlIdx];

				}

			}

		}



		





		clipArtTypeIdxPrev.resize(size);

		clipArtObjectIdxPrev.resize(size);

		clipArtXPrev.resize(size);

		clipArtYPrev.resize(size);

		clipArtZPrev.resize(size);

		clipArtFlipPrev.resize(size);





		for(j=0;j<size;j++)

		{

			clipArtTypeIdxPrev[j] = clipArtTypeIdx[j];

			clipArtObjectIdxPrev[j] = clipArtObjectIdx[j];

			clipArtXPrev[j] = clipArtX[j];

			clipArtYPrev[j] = clipArtY[j];

			clipArtZPrev[j] = clipArtZ[j];

			clipArtFlipPrev[j] = clipArtFlip[j];



			if(m_MapInstance[clipArtTypeIdxPrev[j]][clipArtObjectIdxPrev[j]] == 18)

			{

				px = clipArtX[j]/sf;

				py = clipArtY[j]/sf;

				pz = clipArtZ[j];

			}

		}



		numVisible = size;



		if(numVisible > 5)

		{

			float score = ScoreScene(clipArtTypeIdx, clipArtObjectIdx, clipArtX, clipArtY, clipArtZ, clipArtFlip, attributes);

		//	RenderScene(clipArtTypeIdx, clipArtObjectIdx, clipArtX, clipArtY, clipArtZ, clipArtFlip, outImg);

		//	vt::wstring wstr2(320);

		//	wstr2.format(L"%Sdebug_R.png", m_BaseName);

		//	VtSaveImage(wstr2, outImg);

		//	printf("Sample %d, score %f\n", score);



			if(score < minScore)

			{

			//	printf("%f\n", score);

			//	printf("*", score);



				minScore = score;



				clipArtTypeIdxBest.resize(size);

				clipArtObjectIdxBest.resize(size);

				clipArtXBest.resize(size);

				clipArtYBest.resize(size);

				clipArtZBest.resize(size);

				clipArtFlipBest.resize(size);



				for(j=0;j<size;j++)

				{

					clipArtTypeIdxBest[j] = clipArtTypeIdx[j];

					clipArtObjectIdxBest[j] = clipArtObjectIdx[j];

					clipArtXBest[j] = clipArtX[j];

					clipArtYBest[j] = clipArtY[j];

					clipArtZBest[j] = clipArtZ[j];

					clipArtFlipBest[j] = clipArtFlip[j];

				}



				RenderScene(clipArtTypeIdx, clipArtObjectIdx, clipArtX, clipArtY, clipArtZ, clipArtFlip, outImg);

				vt::wstring wstr2(320);

				wstr2.format(L"%Sdebug_R.png", m_BaseName);

				//VtSaveImage(wstr2, outImg);



			}

		}

	}



	RenderScene(clipArtTypeIdxBest, clipArtObjectIdxBest, clipArtXBest, clipArtYBest, clipArtZBest, clipArtFlipBest, outImg);
	DumpScene(clipArtTypeIdxBest, clipArtObjectIdxBest, clipArtXBest, clipArtYBest, clipArtZBest, clipArtFlipBest, dumpster,scene_id);



	printf(" score :: %f\n", minScore);



	return minScore;

}






void CClipArt::AssignNames()

{

	sprintf(m_InstNames[0], "Helicopter");

	sprintf(m_InstNames[1], "Hot air balloon");

	sprintf(m_InstNames[2], "Cloud");

	sprintf(m_InstNames[3], "Sun");

	sprintf(m_InstNames[4], "Lightning");

	sprintf(m_InstNames[5], "Rain");

	sprintf(m_InstNames[6], "Rocket");

	sprintf(m_InstNames[7], "Airplane");

	sprintf(m_InstNames[8], "Bouncy");

	sprintf(m_InstNames[9], "Slide");

	sprintf(m_InstNames[10], "Sandbox");

	sprintf(m_InstNames[11], "Grill");

	sprintf(m_InstNames[12], "Swing");

	sprintf(m_InstNames[13], "Tent");

	sprintf(m_InstNames[14], "Table");

	sprintf(m_InstNames[15], "Pine tree");

	sprintf(m_InstNames[16], "Oak tree");

	sprintf(m_InstNames[17], "Apple tree");

	sprintf(m_InstNames[18], "Boy");

	sprintf(m_InstNames[19], "Girl");

	sprintf(m_InstNames[20], "Bear");

	sprintf(m_InstNames[21], "Cat");

	sprintf(m_InstNames[22], "Dog");

	sprintf(m_InstNames[23], "Duck");

	sprintf(m_InstNames[24], "Owl");

	sprintf(m_InstNames[25], "Snake");

	sprintf(m_InstNames[26], "Baseball cap");

	sprintf(m_InstNames[27], "Crown");

	sprintf(m_InstNames[28], "Chef's hat");

	sprintf(m_InstNames[29], "Pirate hat");

	sprintf(m_InstNames[30], "Winter cap");

	sprintf(m_InstNames[31], "Bennie");

	sprintf(m_InstNames[32], "Wizard's hat");

	sprintf(m_InstNames[33], "Viking hat");

	sprintf(m_InstNames[34], "Purple glasses");

	sprintf(m_InstNames[35], "Sunglasses");

	sprintf(m_InstNames[36], "Pie");

	sprintf(m_InstNames[37], "Pizza");

	sprintf(m_InstNames[38], "Hotdog");

	sprintf(m_InstNames[39], "Ketchup");

	sprintf(m_InstNames[40], "Mustard");

	sprintf(m_InstNames[41], "Hamburger");

	sprintf(m_InstNames[42], "Soda");

	sprintf(m_InstNames[43], "Baseball ");

	sprintf(m_InstNames[44], "Pail");

	sprintf(m_InstNames[45], "Beach ball");

	sprintf(m_InstNames[46], "Basketball");

	sprintf(m_InstNames[47], "Soccer ball");

	sprintf(m_InstNames[48], "Tennis ball");

	sprintf(m_InstNames[49], "Football");

	sprintf(m_InstNames[50], "Frisbee");

	sprintf(m_InstNames[51], "Baseball bat");

	sprintf(m_InstNames[52], "Balloons");

	sprintf(m_InstNames[53], "Baseball glove");

	sprintf(m_InstNames[54], "Shovel");

	sprintf(m_InstNames[55], "Tennis racket");

	sprintf(m_InstNames[56], "Kite");

	sprintf(m_InstNames[57], "Fire");



}



void CClipArt::ComputeGMM(float (*pos)[2], int numPts, int numGM, float *gmm_mean, float *gmm_std)

{

	printf("%d\n", numPts);

	float minError = 9999999990.f;

	float totalError = 0.f;

	float (*tmp_std)[2] = new float [numGM][2];

	float (*tmp_mean)[2] = new float [numGM][2];

	float (*tmp_mean2)[2] = new float [numGM][2];

	float (*tmp_ct2) = new float [numGM];

	int i, j, k, l;

	int iter, iter2;

	



	for(iter=0;iter<100;iter++)

	{

		totalError = 0.f;



		for(i=0;i<numGM;i++)

		{

			j = rand()%numPts;



			for(k=0;k<2;k++)

				tmp_mean[i][k] = pos[j][k];

		}



		int numIter = 20;

		memset(tmp_std, 0, numGM*2*sizeof(float));



		for(iter2=1;iter2<=numIter;iter2++)

		{

			memset(tmp_ct2, 0, numGM*sizeof(float));

			memset(tmp_mean2, 0, numGM*2*sizeof(float));



			for(i=0;i<numPts;i++)

			{

				float minDist = 99999999.f;

				int minIdx = 0;



				for(j=0;j<numGM;j++)

				{

					float dist = 0.f;



					for(k=0;k<2;k++)

					{

						dist += (pos[i][k] - tmp_mean[j][k])*(pos[i][k] - tmp_mean[j][k]);

					}



					if(dist < minDist)

					{

						minDist = dist;

						minIdx = j;

					}



				}



				for(j=0;j<2;j++)

					tmp_mean2[minIdx][j] += pos[i][j];

				tmp_ct2[minIdx]++;



				if(iter2 == numIter)

				{

					totalError += min(200.f, sqrt(minDist));



					for(k=0;k<2;k++)

					{

						tmp_std[minIdx][k] += (pos[i][k] - tmp_mean[minIdx][k])*(pos[i][k] - tmp_mean[minIdx][k]);

					}

				}

			}



			if(iter2 < numIter)

			for(i=0;i<numGM;i++)

				if(tmp_ct2[i] > 2)

				{

					for(j=0;j<2;j++)

						tmp_mean[i][j] = tmp_mean2[i][j]/tmp_ct2[i];

				}

				else

				{

					k = rand()%numGM;



					for(j=0;j<2;j++)

						tmp_mean[i][j] = tmp_mean[k][j] + 0.1*(float) rand()/(float)RAND_MAX;

				}



			if(iter2 == numIter)

			{

				for(i=0;i<numGM;i++)

					for(j=0;j<2;j++)

						tmp_std[i][j] = tmp_std[i][j]/tmp_ct2[i];



			}



		}





		if(totalError < minError)

		{

			printf(".");

		//	printf("%d %f ", iter, totalError);

			minError = totalError;

		//	printf(" ** ");

			for(i=0;i<numGM;i++)

				for(j=0;j<2;j++)

					gmm_mean[i*2 + j] = tmp_mean[i][j];

			for(i=0;i<numGM;i++)

				for(j=0;j<2;j++)

					gmm_std[i*2 + j] = max(1.f, tmp_std[i][j]);



		//	printf("STD :: %f %f %f\n", gmm_std[0][0], gmm_std[0][1], gmm_std[0][2]);

		//	printf("\n");

		}



	}



	delete [] tmp_mean;

	delete [] tmp_mean2;

	delete [] tmp_ct2;

}



void CClipArt::ComputeRelativePosition(int x0, int x1, int y0, int y1, int flip, float pos[2], int doFlip)

{

	float scale = 1.f;



	pos[0] = scale*(int) (x1 - x0);

	pos[1] = scale*(int) (y1 - y0);



	if(doFlip != 0 && flip != 0)

		pos[0] = -pos[0];



}



void CClipArt::ComputeGMMProbs(float pos[2], float *gmm_mean, float *gmm_std, float *prob, int numGM)

{

	int i, j;



	for(i=0;i<numGM;i++)

	{

		float dist = 0.f;



		// Don't consider depth!!!!!!!

		for(j=0;j<2;j++)

			dist += (gmm_mean[i*2 + j] - pos[j])*(gmm_mean[i*2 + j] - pos[j])/(5.f*gmm_std[i*2 + j]);



		float norm = 1.f;//10000.f/(pow(2.f*(float) VT_PI, 1.5f)*sqrt(gmm_std[i*2 + 0]*gmm_std[i*2 + 1]));

		float nprob = norm*exp(-dist);



		prob[i] = max(prob[i], nprob);

	}

}



void CClipArt::DisplayRelations()

{

	vt::CRGBAImg outImg;

	outImg.Create(300, 300);

	vt::RGBAPix clr;

	clr.r = 255;

	clr.g = 0;

	clr.b = 0;



	int r, c, i, j;

	float prob[NUM_GM_REL];

	vt::wstring wstr2(320);



//	for(i=0;i<50;i++)

	for(i=0;i<m_NumRelations;i++)

	{

		int mIdx = m_RelMap[i];



		if(mIdx >= 0)

		{

		for(r=0;r<300;r++)

			for(c=0;c<300;c++)

			{

				float x = 4.f*(float) (c - 150);

				float y = 4.f*(float) (r - 150);

				float pos[2];



				memset(prob, 0, NUM_GM_REL*sizeof(float));

				ComputeRelativePosition(0, x, 0, y, 0, pos, 0);

				ComputeGMMProbs(pos, m_GMM_mean_RelFlip, m_GMM_std_RelFlip, prob, NUM_GM_REL);



				float sum = 0.f;

				float denom = 0.f;

				for(j=0;j<NUM_GM_REL;j++)

				{

					sum += prob[j]*m_RelAttr[mIdx][j + 2*NUM_GM_REL];

					denom += m_RelAttr[mIdx][j + 2*NUM_GM_REL];

				}



				sum /= denom;



				outImg.Pix(c, r).r = 255;

				outImg.Pix(c, r).g = 0;//255 - (int) min(255.f, 1000.f*sum);

				outImg.Pix(c, r).b = 0;//255 - (int) min(255.f, 1000.f*sum);

				outImg.Pix(c, r).a = (int) min(255.f, 1000.f*sum);

				//outImg.Pix(c, r).b = 80;//(int) min(255.f, 25500000.f*sum);

				//outImg.Pix(c, r).a = 255;

			}



		c = 150;

		r = 150;

		outImg.Pix(c, r).r = 0;

		outImg.Pix(c, r).g = 0;

		outImg.Pix(c, r).b = 0;

		outImg.Pix(c, r).a = 255;

			

		printf(".");

		wstr2.format(L"%SAttributeVisualize2\\%d_FlipLR.png", m_BaseName, i);

		//VtSaveImage(wstr2, outImg);

		}

	}





}





void CClipArt::DisplayExpressions()

{

	vt::CRGBAImg outImg;

	outImg.Create(600, 100);

	vt::RGBAPix clr;

	clr.r = 255;

	clr.g = 0;

	clr.b = 0;

	clr.a = 255;



	int r, c, i, j, k;

	float prob[NUM_GM_REL];

	vt::wstring wstr2(320);



//	for(i=0;i<50;i++)

	for(i=0;i<m_NumRelations;i++)

	{

		clr.r = 255;

		clr.g = 255;

		clr.b = 255;

		outImg.Fill(clr);



		int mIdx = m_RelMap[i];

		clr.r = 255;

		clr.g = 0;

		clr.b = 0;



		if(mIdx >= 0)

		{

			for(j=0;j<m_NumExpressions;j++)

			{

				if(j == 0)

					k = 3;

				if(j == 1)

					k = 0;

				if(j == 2)

					k = 1;

				if(j == 3)

					k = 2;

				if(j == 4)

					k = 4;



				float prob = sqrt(m_LeftAttr[mIdx][m_ExpressionIdx + j]);



				for(r=-50;r<=50;r++)

					for(c=-50;c<=50;c++)

					{

						float dist = (float) (r*r + c*c);

						dist = sqrt(dist);

						dist -= 50.f*prob;

						dist = max(0.f, min(1.f, dist));

						dist = 1.f - dist;



						outImg.Pix(c + k*100 + 50, r + 50).g = min(outImg.Pix(c + k*100 + 50, r + 50).g, (int) ((1.f - dist)*255.f));

						outImg.Pix(c + k*100 + 50, r + 50).b = min(outImg.Pix(c + k*100 + 50, r + 50).b, (int) ((1.f - dist)*255.f));



						//vt::VtDrawCircle(outImg, j*50 + 50.f, 150, 40.f*prob, (byte *) &clr, NULL);

					}

			}

			

			printf(".");

			wstr2.format(L"%SExpressionVisualize\\%d_Left.png", m_BaseName, i);

			//VtSaveImage(wstr2, outImg);

		}

	}





}



void CClipArt::DisplayPoses()

{

	vt::CRGBAImg outImg;

	outImg.Create(700, 100);

	vt::RGBAPix clr;

	clr.r = 255;

	clr.g = 0;

	clr.b = 0;

	clr.a = 255;



	int r, c, i, j, k;

	float prob[NUM_GM_REL];

	vt::wstring wstr2(320);



//	for(i=0;i<50;i++)

	for(i=0;i<m_NumRelations;i++)

	{

		clr.r = 255;

		clr.g = 255;

		clr.b = 255;

		outImg.Fill(clr);



		int mIdx = m_RelMap[i];

		clr.r = 60;

		clr.g = 100;

		clr.b = 255;



		if(mIdx >= 0)

		{

			for(j=0;j<m_NumPoses;j++)

			{

			/*	if(j == 0)

					k = 3;

				if(j == 1)

					k = 0;

				if(j == 2)

					k = 1;

				if(j == 3)

					k = 2;

				if(j == 4)

					k = 4;

					*/

				k = j;

				float prob = sqrt(m_LeftAttr[mIdx][m_PoseIdx + j]);



				for(r=-50;r<=50;r++)

					for(c=-50;c<=50;c++)

					{

						float dist = (float) (r*r + c*c);

						dist = sqrt(dist);

						dist -= 50.f*prob;

						dist = max(0.f, min(1.f, dist));

						dist = 1.f - dist;



						outImg.Pix(c + k*100 + 50, r + 50).r = min(outImg.Pix(c + k*100 + 50, r + 50).r, (int) (dist*60.f + (1.f - dist)*255.f));

						outImg.Pix(c + k*100 + 50, r + 50).g = min(outImg.Pix(c + k*100 + 50, r + 50).g, (int) (dist*100.f + (1.f - dist)*255.f));

						outImg.Pix(c + k*100 + 50, r + 50).b = min(outImg.Pix(c + k*100 + 50, r + 50).b, (int) (dist*255.f + (1.f - dist)*255.f));



						//vt::VtDrawCircle(outImg, j*50 + 50.f, 150, 40.f*prob, (byte *) &clr, NULL);

					}

			}

			

			printf(".");

			wstr2.format(L"%SExpressionVisualize\\%d_Left.png", m_BaseName, i);

			//VtSaveImage(wstr2, outImg);

		}

	}





}







void CClipArt::DisplayAbsolutePosition()

{

	vt::CRGBAImg outImg;

	outImg.Create(CANVAS_WIDTH/4, CANVAS_HEIGHT/4);

	vt::RGBAPix clr;

	clr.r = 255;

	clr.g = 0;

	clr.b = 0;
	
	clr.a= 255;



	LoadAverageAttributes();



	int r, c, i, j, k;

	float prob[NUM_GM_SPAT];

	vt::wstring wstr2(320);



//	for(i=0;i<50;i++)

	for(i=0;i<m_NumInstanceObj;i++)

	{

		for(r=0;r<CANVAS_HEIGHT/4;r++)

			for(c=0;c<CANVAS_WIDTH/4;c++)

			{

				float x = 4.f*(float) (c);

				float y = 4.f*(float) (r);

				float pos[2];

				pos[0] = x;

				pos[1] = y;

				float sum = 0.f;

				float denom = 0.f;



				for(k=0;k<3;k++)

				{

					memset(prob, 0, NUM_GM_SPAT*sizeof(float));

					ComputeGMMProbs(pos, m_GMM_mean_Spat[k], m_GMM_std_Spat[k], prob, NUM_GM_SPAT);



					for(j=0;j<NUM_GM_SPAT;j++)

					{

						denom += m_AverageAttributes[i*m_NumAttributes + NUM_GM_SPAT*k + m_AbsoluteSpatialIdx + j];

						sum += prob[j]*m_AverageAttributes[i*m_NumAttributes + NUM_GM_SPAT*k + m_AbsoluteSpatialIdx + j];

					}

				}



				sum /= denom;



				outImg.Pix(c, r).r = 255;

				outImg.Pix(c, r).g = 255 - (int) min(255.f, 1500.f*sum);

				outImg.Pix(c, r).b = 255 - (int) min(255.f, 1500.f*sum);

				//outImg.Pix(c, r).b = 80;//(int) min(255.f, 25500000.f*sum);

				outImg.Pix(c, r).a = 255;

			}

			

		printf(".");

		wstr2.format(L"%SAttributeVisualize2\\Absolute_%d.png", m_BaseName, i);

		//VtSaveImage(wstr2, outImg);

		

	}





}



void CClipArt::ComputeGMMParameters(std::vector<std::vector<int> > clipArtObjectIdx, std::vector<std::vector<int> > clipArtTypeIdx,std::vector<std::vector<int> > clipArtX, std::vector<std::vector<int> > clipArtY,std::vector<std::vector<int> > clipArtZ, std::vector<std::vector<int> > clipArtFlip, int numScenes)

{

	int i, j, k, l, m;

	int cooccurrenceThreshold = 100;

	// *************************************************** Instance Absolute spatial ****************************************************

	printf("\nInstance Absolute Spatial\n");



	// Use GMM

	int h = CANVAS_HEIGHT;

	int w = CANVAS_WIDTH;



	vt::wstring wstr2(320);

	int maxPts = 500000;

	float (*pos)[2] = new float [500000][2];

	int numPts;

	vt::CRGBAImg outImg;



	outImg.Create(500, 500);

	vt::RGBAPix clr;

	clr.r = 255;

	clr.g = 0;

	clr.b = 0;
	
	clr.a = 255;



	for(int dIdx =0;dIdx<m_NumDepth;dIdx++)

	{

		numPts = 0;

		printf("Computing Relative Position\n");
		for(i=0;i<m_NumInstanceObj;i++)

		{

			for(j=0;j<numScenes;j++)

			{

				for (k = 0; k<int(clipArtX[j].size()); k++)

					if(clipArtX[j][k] >= 0 && clipArtZ[j][k] == dIdx)

				{

					int idx0 = m_MapInstance[clipArtTypeIdx[j][k]][clipArtObjectIdx[j][k]];

					

					if(idx0 == i && numPts < 500000)

					{

						ComputeRelativePosition(0, clipArtX[j][k], 0, clipArtY[j][k], 0, pos[numPts], 0);

						numPts++;

					}



				}

			}

		}



		printf("Computing GMM\n");
		ComputeGMM(pos, numPts, NUM_GM_SPAT, m_GMM_mean_Spat[dIdx], m_GMM_std_Spat[dIdx]);


		printf("Visualization\n");

		outImg.Clear();



		for(k=0;k<numPts;k++)

		{

			int minIdx = 0;

			float minDist = 99999999.f;



			int x = pos[k][0];

			int y = pos[k][1];



			x /= 4;

			y /= 4;



			x += 250;

			y += 250;



			float prob[NUM_GM_SPAT];

			for(l=0;l<NUM_GM_SPAT;l++)

				prob[l] = 0.f;



			ComputeGMMProbs(pos[k], m_GMM_mean_Spat[dIdx], m_GMM_std_Spat[dIdx], prob, NUM_GM_SPAT);



		//	outImg.Pix(x, y).r = (int) min(170.f, 170.f*prob[0]) + 80;

		//	outImg.Pix(x, y).g = (int) min(170.f, 170.f*prob[1]) + 80;

		//	outImg.Pix(x, y).b = (int) min(170.f, 170.f*prob[2]) + 80;

		//	outImg.Pix(x, y).r = 250;

		//	outImg.Pix(x, y).g = 150;

		//	outImg.Pix(x, y).b = 80;
		//	outImg.Pix(x, y).a = 255;

		}





		for(k=0;k<NUM_GM_SPAT;k++)

		{

		//	vt::VtDrawCircle(outImg, m_GMM_mean_Spat[dIdx][k*2 + 0]/4.f + 250.f, m_GMM_mean_Spat[dIdx][k*2 + 1]/4.f + 250.f, 5, clr);

		}


	//	printf("Save Visualization\n");

		//wstr2.format(L"%Sabsolute_%d_%d.png", m_BaseName, dIdx, numPts);

		//VtSaveImage(wstr2, outImg);

	}



	// *************************************************** Instance Relative spatial ****************************************************

	//printf("\nInstance Relative \n");

	numPts = 0;

	for(i=0;i<m_NumInstanceObj;i++)

		for(j=0;j<m_NumInstanceObj;j++)

		{

			for(k=0;k<numScenes;k++)

			{

				for (l = 0; l<int(clipArtX[k].size()); l++)

					if(clipArtX[k][l] >= 0)

				{

					int idx0 = m_MapInstance[clipArtTypeIdx[k][l]][clipArtObjectIdx[k][l]];

					

					if(idx0 == i)

					for (m = 0; m<int(clipArtX[k].size()); m++)

						if(clipArtX[k][m] >= 0 && m != l)

					{

						int idx1 = m_MapInstance[clipArtTypeIdx[k][m]][clipArtObjectIdx[k][m]];



						if(idx1 == j && numPts < 500000)

						{

							ComputeRelativePosition(clipArtX[k][l], clipArtX[k][m], clipArtY[k][l], clipArtY[k][m], clipArtFlip[k][l], pos[numPts], 0);

							numPts++;

						}

					}



				}

			}

		}



	ComputeGMM(pos, numPts, NUM_GM_REL, m_GMM_mean_Rel, m_GMM_std_Rel);



	for(k=0;k<numPts;k++)

	{

		int minIdx = 0;

		float minDist = 99999999.f;



		int x = pos[k][0];

		int y = pos[k][1];



		x /= 4;

		y /= 4;



		x += 250;

		y += 250;



		float prob[NUM_GM_REL];

		for(l=0;l<NUM_GM_REL;l++)

			prob[l] = 0.f;



		ComputeGMMProbs(pos[k], m_GMM_mean_Rel, m_GMM_std_Rel, prob, NUM_GM_REL);



	//	outImg.Pix(x, y).r = (int) min(170.f, 170.f*prob[0]) + 80;

	//	outImg.Pix(x, y).g = (int) min(170.f, 170.f*prob[1]) + 80;

	//	outImg.Pix(x, y).b = (int) min(170.f, 170.f*prob[2]) + 80;

	//	outImg.Pix(x, y).r = 250;

	//	outImg.Pix(x, y).g = 150;

	//	outImg.Pix(x, y).b = 80;

	}



	for(k=0;k<NUM_GM_REL;k++)

	{

	//	vt::VtDrawCircle(outImg, m_GMM_mean_Rel[k*2 + 0]/4.f + 250.f, m_GMM_mean_Rel[k*2 + 1]/4.f + 250.f, 5, clr);

	}



	//wstr2.format(L"%Srelative_%d.png", m_BaseName, i, j, numPts);

	//VtSaveImage(wstr2, outImg);

		

	// *************************************************** Instance Relative spatial FLIP ****************************************************

	//printf("\nInstance Relative FLIP \n");

	numPts = 0;

	for(i=0;i<m_NumInstanceObj;i++)

		for(j=0;j<m_NumInstanceObj;j++)

		{

			for(k=0;k<numScenes;k++)

			{

				for (l = 0; l<int(clipArtX[k].size()); l++)

					if(clipArtX[k][l] >= 0)

				{

					int idx0 = m_MapInstance[clipArtTypeIdx[k][l]][clipArtObjectIdx[k][l]];

					

					if(idx0 == i)

					for (m = 0; m<int(clipArtX[k].size()); m++)

						if(clipArtX[k][m] >= 0 && m != l)

					{

						int idx1 = m_MapInstance[clipArtTypeIdx[k][m]][clipArtObjectIdx[k][m]];



						if(idx1 == j && numPts < 500000)

						{

							ComputeRelativePosition(clipArtX[k][l], clipArtX[k][m], clipArtY[k][l], clipArtY[k][m], clipArtFlip[k][l], pos[numPts], 1);

							numPts++;

						}

					}



				}

			}

		}



	ComputeGMM(pos, numPts, NUM_GM_REL, m_GMM_mean_RelFlip, m_GMM_std_RelFlip);

		

	for(k=0;k<numPts;k++)

	{

		int minIdx = 0;

		float minDist = 99999999.f;



		int x = pos[k][0];

		int y = pos[k][1];



		x /= 4;

		y /= 4;



		x += 250;

		y += 250;



		float prob[NUM_GM_REL];

		for(l=0;l<NUM_GM_REL;l++)

			prob[l] = 0.f;



		ComputeGMMProbs(pos[k], m_GMM_mean_RelFlip, m_GMM_std_RelFlip, prob, NUM_GM_REL);



	//	outImg.Pix(x, y).r = (int) min(170.f, 170.f*prob[0]) + 80;

	//	outImg.Pix(x, y).g = (int) min(170.f, 170.f*prob[1]) + 80;

	//	outImg.Pix(x, y).b = (int) min(170.f, 170.f*prob[2]) + 80;

	//	outImg.Pix(x, y).r = 250;

	//	outImg.Pix(x, y).g = 150;

	//	outImg.Pix(x, y).b = 80;

	}



	for(k=0;k<NUM_GM_REL;k++)

	{

	//	vt::VtDrawCircle(outImg, m_GMM_mean_RelFlip[k*2 + 0]/4.f + 250.f, m_GMM_mean_RelFlip[k*2 + 1]/4.f + 250.f, 5, clr);

	}



	wstr2.format(L"%Srelative_flip_%d.png", m_BaseName, i, j, numPts);

	//VtSaveImage(wstr2, outImg);





	char name[1024];

	FILE *out;

	sprintf(name, "%sGMM_%d_%d_%d.txt", m_BaseName, NUM_GM_SPAT, NUM_GM_REL, m_NumAttributes);

	out = fopen(name, "w");





	for(i=0;i<m_NumDepth;i++)

		for(j=0;j<NUM_GM_SPAT;j++)

		{

			fprintf(out, "%f\t%f\t%f\t%f\t\n", m_GMM_mean_Spat[i][j*2 + 0], m_GMM_mean_Spat[i][j*2 + 1], m_GMM_std_Spat[i][j*2 + 0], m_GMM_std_Spat[i][j*2 + 1]);

		}



	fprintf(out, "\n");



	for(k=0;k<NUM_GM_REL;k++)

	{

		fprintf(out, "%f\t%f\t%f\t%f\t\n", m_GMM_mean_Rel[k*2 + 0], m_GMM_mean_Rel[k*2 + 1], 

			m_GMM_std_Rel[k*2 + 0], m_GMM_std_Rel[k*2 + 1]);

	}

	fprintf(out, "\n");



	for(k=0;k<NUM_GM_REL;k++)

	{

		fprintf(out, "%f\t%f\t%f\t%f\t\n", m_GMM_mean_RelFlip[k*2 + 0], m_GMM_mean_RelFlip[k*2 + 1], 

			m_GMM_std_RelFlip[k*2 + 0], m_GMM_std_RelFlip[k*2 + 1]);

	}

	fprintf(out, "\n");



	fclose(out);



}







void CClipArt::ReadGMMParamters()

{

	int i, j, k;

	char name[1024];

	FILE *in;

	sprintf(name, "%sGMM_%d_%d_%d.txt", m_BaseName, NUM_GM_SPAT, NUM_GM_REL, m_NumAttributes);

	in = fopen(name, "r");





	for(i=0;i<m_NumDepth;i++)

		for(j=0;j<NUM_GM_SPAT;j++)

		{

			fscanf(in, "%f\t%f\t%f\t%f\t\n", &(m_GMM_mean_Spat[i][j*2 + 0]), &(m_GMM_mean_Spat[i][j*2 + 1]), &(m_GMM_std_Spat[i][j*2 + 0]), &(m_GMM_std_Spat[i][j*2 + 1]));

		}





	for(k=0;k<NUM_GM_REL;k++)

	{

		fscanf(in, "%f\t%f\t%f\t%f\t\n", &(m_GMM_mean_Rel[k*2 + 0]), &(m_GMM_mean_Rel[k*2 + 1]), 

			&(m_GMM_std_Rel[k*2 + 0]), &(m_GMM_std_Rel[k*2 + 1]));

	}



	for(k=0;k<NUM_GM_REL;k++)

	{

		fscanf(in, "%f\t%f\t%f\t%f\t\n", &(m_GMM_mean_RelFlip[k*2 + 0]), &(m_GMM_mean_RelFlip[k*2 + 1]), 

			&(m_GMM_std_RelFlip[k*2 + 0]), &(m_GMM_std_RelFlip[k*2 + 1]));

	}



	fclose(in);



}



// Object occurrence (58 entries)

// Object co-occurrence (3364)

void CClipArt::ComputeAttributes(std::vector<int> clipArtObjectIdx, std::vector<int> clipArtTypeIdx, std::vector<int> clipArtX, std::vector<int> clipArtY, std::vector<int> clipArtZ, std::vector<int> clipArtFlip, int numClipArt, float *attributes)

{

	int j, k, l, m, n;

	float backgroundProb = 0.001f;

	float smallNum = -1000000.f;

	int *iocc = new int [m_NumInstanceObj];



	int attrIdx = 0;

	// *************************************************** instance occurrence ****************************************************
	//printf("instance occurrence\n");


	for(j=0;j<m_NumInstanceObj;j++)

	{

		attributes[j*m_NumAttributes + attrIdx] = 0.f;

	}



	//printf("instance occurrence 2\n");
	for(j=0;j<numClipArt;j++)

	{

		if(clipArtX[j] >= 0)

		{
			//printf("instance occurrence 3 %d %d \n", clipArtTypeIdx[j], clipArtObjectIdx[j]);

			int instIdx = m_MapInstance[clipArtTypeIdx[j]][clipArtObjectIdx[j]];

			attributes[instIdx*m_NumAttributes + attrIdx] = 1.f;

		}

	}



	attrIdx++;



	// *************************************************** Instance Absolute spatial ****************************************************
	//printf("Instance Absolute spatial\n");



	// Use GMM

	int h = CANVAS_HEIGHT;

	int w = CANVAS_WIDTH;



	vt::wstring wstr2(320);



	for(j=0;j<m_NumInstanceObj;j++)

	{

		float *prob = new float [m_NumDepth*NUM_GM_SPAT];



		for(k=0;k<m_NumDepth*NUM_GM_SPAT;k++)

			prob[k] = 0.f;



		bool found = false;

		for(k=0;k<numClipArt;k++)

			if(clipArtX[k] >= 0)

		{

			int idx0 = m_MapInstance[clipArtTypeIdx[k]][clipArtObjectIdx[k]];

					

			if(idx0 == j)

			{

				int dIdx = clipArtZ[k];

				float posit[2];

				ComputeRelativePosition(0, clipArtX[k], 0, clipArtY[k], 0, posit, 0);

				ComputeGMMProbs(posit, m_GMM_mean_Spat[dIdx], m_GMM_std_Spat[dIdx], &(prob[dIdx*NUM_GM_SPAT]), NUM_GM_SPAT);

				found = true;

			}

		}

	

		float denom = backgroundProb;

		for(l=0;l<m_NumDepth*NUM_GM_SPAT;l++)

			denom += prob[l];

		for(l=0;l<m_NumDepth*NUM_GM_SPAT;l++)

			prob[l] /= denom;



		for(l=0;l<m_NumDepth*NUM_GM_SPAT;l++)

		{

			attributes[j*m_NumAttributes + attrIdx + l] = prob[l];

		}



		delete [] prob;

	}



	attrIdx += m_NumDepth*NUM_GM_SPAT;



	// *************************************************** instance co-occurrence ****************************************************
	//printf("instance co-occurrence\n");



	memset(iocc, 0, m_NumInstanceObj*sizeof(int));



	for(j=0;j<m_NumInstanceObj;j++)

		for(k=0;k<m_NumInstanceObj;k++)

		{

			attributes[j*m_NumAttributes + attrIdx + k] = 0;

		}



	for(j=0;j<numClipArt;j++)

		if(clipArtX[j] >= 0)

	{

		int idx0 = m_MapInstance[clipArtTypeIdx[j]][clipArtObjectIdx[j]];

		iocc[idx0] = 1;

	}



	for(j=0;j<numClipArt;j++)

		if(clipArtX[j] >= 0)

	{

		int idx0 = m_MapInstance[clipArtTypeIdx[j]][clipArtObjectIdx[j]];

		for(k=0;k<m_NumInstanceObj;k++)

			attributes[idx0*m_NumAttributes + attrIdx + k] = iocc[k];

	}





	attrIdx += m_NumInstanceObj;



	// *************************************************** Instance Relative spatial ****************************************************
	//printf("Instance Relative spatial\n");



/*	for(j=0;j<m_NumInstanceObj;j++)

	{

		for(k=0;k<m_NumInstanceObj*NUM_GM_REL;k++)

			attributes[j*m_NumAttributes + attrIdx + k] = 0;



		for(k=0;k<m_NumInstanceObj;k++)

			if(j != k)

		{

			float prob[NUM_GM_REL];



			for(l=0;l<NUM_GM_REL;l++)

				prob[l] = 0.f;



			bool found = false;

			for(l=0;l<numClipArt;l++)

				if(clipArtX[l] >= 0)

			{

				int idx0 = m_MapInstance[clipArtTypeIdx[l]][clipArtObjectIdx[l]];

					

				if(idx0 == j)

				for(m=0;m<numClipArt;m++)

					if(clipArtX[m] >= 0 && m != l)

				{

					int idx1 = m_MapInstance[clipArtTypeIdx[m]][clipArtObjectIdx[m]];



					if(idx1 == k)

					{

						float posit[2];

						ComputeRelativePosition(clipArtX[l], clipArtX[m], clipArtY[l], clipArtY[m], clipArtFlip[l], posit, 0);

						ComputeGMMProbs(posit, m_GMM_mean_Rel, m_GMM_std_Rel, prob, NUM_GM_REL);

						found = true;

					}

				}

			}



			float denom = backgroundProb;

			for(l=0;l<NUM_GM_REL;l++)

				denom += prob[l];

			for(l=0;l<NUM_GM_REL;l++)

				prob[l] /= denom;



			for(l=0;l<NUM_GM_REL;l++)

				attributes[j*m_NumAttributes + attrIdx + k*NUM_GM_REL + l] = prob[l];

		}

	}

	*/

	attrIdx += m_NumInstanceObj*NUM_GM_REL;



	// *************************************************** Instance Relative spatial FLIP ****************************************************
	//printf("Instance Relative spatial FLIP\n");



	float prob[NUM_GM_REL];



	for(j=0;j<m_NumInstanceObj;j++)

	{

		memset(&(attributes[j*m_NumAttributes + attrIdx]), 0, m_NumInstanceObj*NUM_GM_REL*sizeof(float));



		for(k=0;k<m_NumInstanceObj;k++)

			if(j != k)

		{



			bool found = false;

			for(l=0;l<numClipArt;l++)

				if(clipArtX[l] >= 0)

			{

				int idx0 = m_MapInstance[clipArtTypeIdx[l]][clipArtObjectIdx[l]];

					

				if(idx0 == j)

				for(m=0;m<numClipArt;m++)

					if(clipArtX[m] >= 0 && m != l)

				{

					for(n=0;n<NUM_GM_REL;n++)

						prob[n] = 0.f;



					int idx1 = m_MapInstance[clipArtTypeIdx[m]][clipArtObjectIdx[m]];



					if(idx1 == k)

					{

						float posit[2];



						ComputeRelativePosition(clipArtX[l], clipArtX[m], clipArtY[l], clipArtY[m], clipArtFlip[l], posit, 1);

						ComputeGMMProbs(posit, m_GMM_mean_RelFlip, m_GMM_std_RelFlip, prob, NUM_GM_REL);

						found = true;



						float denom = backgroundProb;

						for(n=0;n<NUM_GM_REL;n++)

							denom += prob[n];

						for(n=0;n<NUM_GM_REL;n++)

							prob[n] /= denom;



						memcpy(&(attributes[j*m_NumAttributes + attrIdx + k*NUM_GM_REL]), prob, NUM_GM_REL*sizeof(float));

					}

				}



			}



		}

	}



	attrIdx += m_NumInstanceObj*NUM_GM_REL;



// *************************************************** Instance Relative Depth ****************************************************
	//printf("Instance Relative Depth\n");



	memset(iocc, 0, m_NumInstanceObj*sizeof(int));



	for(j=0;j<m_NumInstanceObj;j++)

		for(k=0;k<3*m_NumInstanceObj;k++)

		{

			attributes[j*m_NumAttributes + attrIdx + k] = 0;

		}



	for(j=0;j<numClipArt;j++)

		if(clipArtX[j] >= 0)

	{

		int idx0 = m_MapInstance[clipArtTypeIdx[j]][clipArtObjectIdx[j]];

		iocc[idx0] = clipArtZ[j] + 1;

	}



	for(j=0;j<numClipArt;j++)

		if(clipArtX[j] >= 0)

	{

		int idx0 = m_MapInstance[clipArtTypeIdx[j]][clipArtObjectIdx[j]];

		for(k=0;k<m_NumInstanceObj;k++)

		{

			if(iocc[k] > 0)

			{

				if(iocc[idx0] > iocc[k])

					attributes[idx0*m_NumAttributes + attrIdx + k*3] = 1.f;

				if(iocc[idx0] == iocc[k])

					attributes[idx0*m_NumAttributes + attrIdx + k*3 + 1] = 1.f;

				if(iocc[idx0] < iocc[k])

					attributes[idx0*m_NumAttributes + attrIdx + k*3 + 2] = 1.f;

			}

		}

	}



	attrIdx += 3*m_NumInstanceObj;



	// *************************************************** Person ****************************************************
	//printf("Person\n");



	// 2 people

	// 5 expressions

	// 7 poses

		

	for(j=0;j<m_NumInstanceObj;j++)

		for(k=0;k<m_NumPersonAttrs;k++)

			attributes[j*m_NumAttributes + attrIdx + k] = 0;



	for(j=0;j<numClipArt;j++)

		if(clipArtX[j] >= 0)

	{

		if(clipArtTypeIdx[j] == 2 || clipArtTypeIdx[j] == 3)

		{

			int idx0 = m_MapInstance[clipArtTypeIdx[j]][clipArtObjectIdx[j]];



			int expression = clipArtObjectIdx[j]%5;

			int pose = clipArtObjectIdx[j]/5;



			attributes[idx0*m_NumAttributes + attrIdx + expression] = 1.f;

			attributes[idx0*m_NumAttributes + attrIdx + m_NumExpressions + pose] = 1.f;

		}

	}



	attrIdx += m_NumExpressions + m_NumPoses;



	// *************************************************** Instance Relative Head ****************************************************
	//printf(" Instance Relative Head\n");



	for(j=0;j<m_NumInstanceObj;j++)

		for(k=0;k<m_NumClothing;k++)

			attributes[j*m_NumAttributes + attrIdx + k] = 0;



	for(j=0;j<numClipArt;j++)

		if(clipArtX[j] >= 0)

	{

		int idx0 = m_MapInstance[clipArtTypeIdx[j]][clipArtObjectIdx[j]];

		if(clipArtTypeIdx[j] == 2 || clipArtTypeIdx[j] == 3) 

		for(k=0;k<numClipArt;k++)

			if(j != k && clipArtX[k] >= 0 && clipArtTypeIdx[k] == 5)

		{

			int idx1 = m_MapInstance[clipArtTypeIdx[k]][clipArtObjectIdx[k]];

			float x, y;

			int hx, hy;



			ComputeHeadPosition(clipArtTypeIdx[j], clipArtObjectIdx[j], clipArtX[j], clipArtY[j], clipArtZ[j], clipArtFlip[j], clipArtObjectIdx[k], hx, hy);



			x = (float) (clipArtX[k]) - m_ClipArtW[clipArtTypeIdx[k]][clipArtObjectIdx[k]][clipArtZ[k]]/2;

			y = (float) (clipArtY[k]) - m_ClipArtH[clipArtTypeIdx[k]][clipArtObjectIdx[k]][clipArtZ[k]]/2;



			x = x - (float) hx;

			y = y - (float) hy;

							  

			float prob = exp(-(x*x + y*y)/(2.f*1000.f));



			if(prob > 0.1f)

				attributes[idx0*m_NumAttributes + attrIdx + clipArtObjectIdx[k]] = 1.f;

		}

	}



	attrIdx += m_NumClothing;



	// *************************************************** Instance Relative Hand ****************************************************
	//printf(" Instance Relative Hand\n");

/*	

	for(j=0;j<m_NumInstanceObj;j++)

		for(k=0;k<m_NumInstanceObj;k++)

			attributes[j*m_NumAttributes + attrIdx + k] = 0;



	for(j=0;j<numClipArt;j++)

		if(clipArtX[j] >= 0)

	{

		int idx0 = m_MapInstance[clipArtTypeIdx[j]][clipArtObjectIdx[j]];

		if(clipArtTypeIdx[j] == 2 || clipArtTypeIdx[j] == 3) 

		for(k=0;k<numClipArt;k++)

			if(j != k && clipArtX[k] >= 0)

		{

			int idx1 = m_MapInstance[clipArtTypeIdx[k]][clipArtObjectIdx[k]];

			float x, y;

			float hx, hy;



			// each hand

			for(l=0;l<2;l++)

			{

				if(clipArtTypeIdx[j] == 2)

				{

					hx = m_HandPos[0][l][clipArtObjectIdx[j]/m_NumExpressions][0];

					hy = m_HandPos[0][l][clipArtObjectIdx[j]/m_NumExpressions][1];

				}

				if(clipArtTypeIdx[j] == 3)

				{

					hx = m_HandPos[1][l][clipArtObjectIdx[j]/m_NumExpressions][0];

					hy = m_HandPos[1][l][clipArtObjectIdx[j]/m_NumExpressions][1];

				}



				if(clipArtZ[j] == 1)

				{

					hx *= m_ScaleFactor;

					hy *= m_ScaleFactor;

				}



				if(clipArtZ[j] == 2)

				{

					hx *= m_ScaleFactor*m_ScaleFactor;

					hy *= m_ScaleFactor*m_ScaleFactor;

				}



				if(clipArtFlip[j] > 0)

					hx = m_ClipArtW[clipArtTypeIdx[j]][clipArtObjectIdx[j]][clipArtZ[j]] - hx;



				hx += clipArtX[j] - m_ClipArtW[clipArtTypeIdx[j]][clipArtObjectIdx[j]][clipArtZ[j]]/2;

				hy += clipArtY[j] - m_ClipArtH[clipArtTypeIdx[j]][clipArtObjectIdx[j]][clipArtZ[j]]/2;

				x = 0.f;

				y = 0.f;



				// Handle special cases where object is not grabed in center

				if(idx1 == 51 || idx1 == 55 || idx1 == 56)

				{

					x = (float) -m_ClipArtW[clipArtTypeIdx[k]][clipArtObjectIdx[k]][clipArtZ[k]]/2;

					y = (float) m_ClipArtH[clipArtTypeIdx[k]][clipArtObjectIdx[k]][clipArtZ[k]]/2;



					if(clipArtFlip[k] > 0)

						x = -x;



				}



				if(idx1 == 44)

				{

					y = (float) -m_ClipArtH[clipArtTypeIdx[k]][clipArtObjectIdx[k]][clipArtZ[k]]/2;

				}



				if(idx1 == 54)

				{

					x = (float) m_ClipArtW[clipArtTypeIdx[k]][clipArtObjectIdx[k]][clipArtZ[k]]/2;

					y = (float) -m_ClipArtH[clipArtTypeIdx[k]][clipArtObjectIdx[k]][clipArtZ[k]]/2;



					if(clipArtFlip[k] > 0)

						x = -x;

				}



				if(idx1 == 52)

				{

					y = (float) m_ClipArtH[clipArtTypeIdx[k]][clipArtObjectIdx[k]][clipArtZ[k]]/2;

				}



				x += (float) (clipArtX[k]);

				y += (float) (clipArtY[k]);



				float dx = x - hx;

				float dy = y - hy;

							  

				float prob = exp(-(dx*dx + dy*dy)/(2.f*1000.f));

				attributes[idx0*m_NumAttributes + attrIdx + idx1] = max((int) attributes[idx0*m_NumAttributes + attrIdx + idx1], prob);

			}



		}

	}

	*/

	attrIdx += m_NumInstanceObj;



	delete [] iocc;



} // ComputeAttributes

	

void CClipArt::ComputeHeadPosition(int typeIdx, int objIdx, int x, int y, int z, int flip, int clothingIdx, int &hx, int &hy)

{

	if(typeIdx == 2)

	{

		hx = m_HeadPos[0][objIdx/m_NumExpressions][0];

		hy = m_HeadPos[0][objIdx/m_NumExpressions][1];

	}

	if(typeIdx == 3)

	{

		hx = m_HeadPos[1][objIdx/m_NumExpressions][0];

		hy = m_HeadPos[1][objIdx/m_NumExpressions][1];

	}



	if(clothingIdx == 8 || clothingIdx == 9)

		hy += 30;



	if(z == 1)

	{

		hx *= m_ScaleFactor;

		hy *= m_ScaleFactor;

	}



	if(z == 2)

	{

		hx *= m_ScaleFactor*m_ScaleFactor;

		hy *= m_ScaleFactor*m_ScaleFactor;

	}



	if(flip > 0)

		hx = m_ClipArtW[typeIdx][objIdx][z] - hx;



//	printf("%d %d %d:: %d %d\n", objIdx, z, flip, hx, hy);



	hx += x - m_ClipArtW[typeIdx][objIdx][z]/2;

	hy += y - m_ClipArtH[typeIdx][objIdx][z]/2;





}



void CClipArt::ScoreCRF(int start, int end, std::vector<std::vector<int> > clipArtObjectIdx, std::vector<std::vector<int> > clipArtTypeIdx, 

	std::vector<std::vector<int> > clipArtX, std::vector<std::vector<int> > clipArtY, 

							std::vector<std::vector<int> > clipArtZ, std::vector<std::vector<int> > clipArtFlip, int numScenes)

{

	int i, j, k, l, m, n, o;

	char name[1024];

	FILE *out;

	float *attributes = new float [m_NumInstanceObj*m_NumAttributes];



	LoadAverageAttributes();

//	LoadTestingTuples();

	LoadNounMap();



	sprintf(name, "%sScoreCRF.txt", m_BaseName);

	out = fopen(name, "w");

printf("m_Tuple.size():%d",int(m_Tuple.size()));

	for(i=start;i<end;i++)

//	for(i=0;i<m_Tuple.size();i++)

	{

		printf("\nIdx:: %d\n", i);

		UpdateAttributesWithTuples(attributes, m_Tuple[i]);



		for(j=0;j<numScenes;j++)

		{

			float score = ScoreScene(clipArtTypeIdx[j], clipArtObjectIdx[j], clipArtX[j],  clipArtY[j], clipArtZ[j], 

						   clipArtFlip[j], attributes);



			fprintf(out, "%f\t", score);

		}

		fprintf(out, "\n");

	}



	fclose(out);



}



void CClipArt::SaveFeatures(std::vector<std::vector<int> > clipArtObjectIdx, std::vector<std::vector<int> > clipArtTypeIdx, 

	std::vector<std::vector<int> > clipArtX, std::vector<std::vector<int> > clipArtY, 

							std::vector<std::vector<int> > clipArtZ, std::vector<std::vector<int> > clipArtFlip, int numScenes)

{

	int i, j, k, l, m, n, o;

	char name[1024];

	FILE *out;



	printf("Size %d\n", m_NumAttributes);

	float *attributes = new float [m_NumInstanceObj*m_NumAttributes];

	printf("done.\n");


	
	ComputeGMMParameters(clipArtObjectIdx, clipArtTypeIdx, clipArtX, clipArtY, clipArtZ, clipArtFlip, numScenes);
	ReadGMMParamters();


	printf("Saving... ");



	sprintf(name, "%sAttributes_%d_%d_%d.txt", m_BaseName, NUM_GM_SPAT, NUM_GM_REL, m_NumAttributes);

	out = fopen(name, "w");



	for(i=0;i<numScenes;i++)

	{
		printf("Computing Attributes %d ",i);

		ComputeAttributes(clipArtObjectIdx[i], clipArtTypeIdx[i], clipArtX[i], 

			clipArtY[i], clipArtZ[i], clipArtFlip[i], int(clipArtX[i].size()), attributes);


		printf("Done Computing Attributes %d, some post processing ", i);
		

		int ct = 0;

		for(j=0;j<m_NumInstanceObj;j++)

		{

			if(attributes[j*m_NumAttributes] != 0)

				ct++;

		}

		

		fprintf(out, "%d\n", ct);



		for(j=0;j<m_NumInstanceObj;j++)

		{

			if(attributes[j*m_NumAttributes] != 0)

			{

				fprintf(out, "%d\t", j);

				for(k=0;k<m_NumAttributes;k++)

				{

					fprintf(out, "%d\t", (int) (255.f*attributes[j*m_NumAttributes + k]));

				}

			

				fprintf(out, "\n");

			}

		}

	}



	fclose(out);

	

} // SaveFeatures





void CClipArt::ComputeMostCommonPrimarySecondaryNouns()

{

	FILE *in;

	char name[1024];

	int i, j, k, l, lIdx, mIdx, rIdx;

	int pastIdx = -1;

	m_Tuple.resize(0);

	int ct = -1;

		

	LoadNounMap();



	sprintf(name, "%sTuples.txt", m_BaseName);

	in = fopen(name, "r");



	printf("Reading tuples\n");



	//FILE *out;

	//char name[1024];

	//sprintf(name, "%sTupleMap.txt", m_BaseName);

	//printf("Opening %s\n", name);

	//out = fopen(name, "w");



	m_Tuple.resize(m_NumRelations);



	for(i=0;i<m_NumRelations;i++)

		m_Tuple[i].resize(0);



	while(fscanf(in, "%d", &i) != EOF)

	{

		fscanf(in, "%d\%d\%d", &lIdx, &mIdx, &rIdx);

		//printf("%d %d %d\n", lIdx, mIdx, rIdx);



		int lMIdx = m_NounMap[lIdx];

		int rMIdx = m_NounMap[rIdx];





		if(lMIdx >= 0 && rMIdx >= 0)

		{

			std::vector<int> tuple;

			tuple.push_back(lMIdx);

			tuple.push_back(mIdx);

			tuple.push_back(rMIdx);



			m_Tuple[mIdx].push_back(tuple);

			ct++;



		//	fprintf(out, "%d\t%d\n", i, 9000 + m_Tuple.size() - 1);

		}



	}



	//fclose(out);



	printf("Number of tuples = %d :: Scenes %d\n", ct, int(m_Tuple.size()));

	fclose(in);



	FILE *out;

	sprintf(name, "%sCommonNouns.txt", m_BaseName);

	printf("Opening %s\n", name);

	out = fopen(name, "w");



	std::vector<int> pNounCt;

	std::vector<int> sNounCt;



	pNounCt.resize(m_NumInstanceObj);

	sNounCt.resize(m_NumInstanceObj);



	for(i=0;i<m_NumRelations;i++)

	{

		for(j=0;j<m_NumInstanceObj;j++)

		{

			pNounCt[j] = 0;

			sNounCt[j] = 0;

		}



		for(j=0;j<m_Tuple[i].size();j++)

		{

			pNounCt[m_Tuple[i][j][0]]++;

			sNounCt[m_Tuple[i][j][2]]++;

		}



		int maxSN = -1;

		int maxPN = -1;

		int maxValSN = 0;

		int maxValPN = 0;



		for(j=0;j<m_NumInstanceObj;j++)

		{

			if(pNounCt[j] > maxValPN)

			{

				maxValPN = pNounCt[j];

				maxPN = j;

			}

			if(sNounCt[j] > maxValSN)

			{

				maxValSN = sNounCt[j];

				maxSN = j;

			}

		}



		fprintf(out, "%d\t%d\t%d\n", i, maxPN, maxSN);

	}





	fclose(out);

}



void CClipArt::LoadTestingTuples()

{

	FILE *in;

	char name[1024];

	int i, lIdx, mIdx, rIdx;

	int pastIdx = -1;

	m_Tuple.resize(0);

	int ct = -1;



	sprintf(name, "%sTuples.txt", m_BaseName);

	in = fopen(name, "r");



	printf("Reading tuples\n");



	//FILE *out;

	//char name[1024];

	//sprintf(name, "%sTupleMap.txt", m_BaseName);

	//printf("Opening %s\n", name);

	//out = fopen(name, "w");



	m_Tuple.resize(1000);



	for(i=0;i<1000;i++)

		m_Tuple[i].resize(0);



	while(fscanf(in, "%d", &i) != EOF && i < m_TestingIdx + 1000)

	{

		fscanf(in, "%d\%d\%d", &lIdx, &mIdx, &rIdx);



		if(i >= m_TestingIdx && i < m_TestingIdx + 1000)

		{

			std::vector<int> tuple;

			tuple.push_back(lIdx);

			tuple.push_back(mIdx);

			tuple.push_back(rIdx);



			m_Tuple[i - m_TestingIdx].push_back(tuple);

			ct++;



		//	fprintf(out, "%d\t%d\n", i, 9000 + m_Tuple.size() - 1);

		}



	}



	//fclose(out);



	printf("Number of tuples = %d :: Scenes %d\n", ct, int(m_Tuple.size()));

	fclose(in);

}



void CClipArt::LoadTuples()

{

	FILE *in;


	int i, lIdx, mIdx, rIdx;

	int pastIdx = -1;

	m_Tuple.resize(0);

	int ct = -1;

	char line_buffer[1000];

	//in = fopen(name, "r");



	fprintf(stderr,"\nREADY\n");



	//FILE *out;

	//char name[1024];

	//sprintf(name, "%sTupleMap.txt", m_BaseName);

	//printf("Opening %s\n", name);

	//out = fopen(name, "w");



	m_Tuple.resize(1);



	for(i=0;i<1;i++)

		m_Tuple[i].resize(0);


	do
	{
		std::cin.getline(line_buffer,1000);
		printf("%s\n", line_buffer);
		if(strcmp(line_buffer,"END")==0)
			break;
		
		if (sscanf(line_buffer,"%d\%d\%d", &lIdx, &mIdx, &rIdx)==3)
		{



			printf("%d\%d\%d\n", lIdx, mIdx, rIdx);

			std::vector<int> tuple;

			tuple.push_back(lIdx);

			tuple.push_back(mIdx);

			tuple.push_back(rIdx);



			m_Tuple[0].push_back(tuple);

			ct++;
		}
	}while(true);



	//fclose(out);



	printf("Number of tuples = %d :: Scenes %d\n", ct, int(m_Tuple.size()));

	//fclose(in);

}

void CClipArt::FixNaming()

{

	int i, j, k;

	FILE *in;

	char name[1024];

	sprintf(name, "%sTupleMap.txt", m_BaseName);

	printf("Opening %s\n", name);

	in = fopen(name, "r");

	vt::wstring wstr2(320);

	vt::CRGBAImg img;



	for(i=0;i<1000;i++)

	{

		fscanf(in, "%d\t%d", &j, &k);

		img.Create(0,0);



		printf("Opening %sRenderingsNoun\\10K_Noun_%d_%d.png\n", m_BaseName, (k)/3, (k)%3);

		wstr2.format(L"%SRenderingsNoun\\10K_Noun_%d_%d.png", m_BaseName, (k)/3, (k)%3);

	//	VtLoadImage(wstr2, img);



		if(img.imgx < 50)

			return;



		printf("Saving %sRenderingsNounFixed\\10K_Noun_%d_%d.png\n", m_BaseName, (j)/3, (j)%3);

		wstr2.format(L"%SRenderingsNounFixed\\10K_Noun_%d_%d.png", m_BaseName, (j)/3, (j)%3);

		//VtSaveImage(wstr2, img);



	}



	fclose(in);

}



void CClipArt::UpdateAttributesWithTuples(float *attributes, std::vector<std::vector<int> > tuples)

{

	int j, k;

	float *attributesCt = new float [m_NumInstanceObj*m_NumAttributes];

	

	for(j=0;j<m_NumInstanceObj*m_NumAttributes;j++)

	{

		attributes[j] = m_AverageAttributes[j];

		attributesCt[j] = 0.f;

	}		



	for(j=0;j<tuples.size();j++)

	{

		int lIdx = tuples[j][0];

		int mIdx = tuples[j][1];

		int rIdx = tuples[j][2];



		int lMIdx = -1;
		if (lIdx>=0)
			lMIdx=m_NounMap[lIdx];

		int rMIdx = -1;
		if (rIdx>=0)
			rMIdx=m_NounMap[rIdx];

		int mMIdx = -1;
		if (mIdx>=0) 
			mMIdx= m_RelMap[mIdx];

		printf("%d %d %d\n", lMIdx, mMIdx, rMIdx);



		if(lMIdx >= 0 && mMIdx >= 0)

		{

			for(k=m_ExpressionIdx;k<m_ExpressionIdx + m_NumExpressions + m_NumPoses;k++)

				attributes[lMIdx*m_NumAttributes + k] *= m_LeftAttr[mMIdx][k] + 0.0001f;



			float denom = 0.000001f;

			for(k=m_ExpressionIdx;k<m_ExpressionIdx + m_NumExpressions;k++)

				denom += attributes[lMIdx*m_NumAttributes + k];

			for(k=m_ExpressionIdx;k<m_ExpressionIdx + m_NumExpressions;k++)

				attributes[lMIdx*m_NumAttributes + k] /= denom;



			denom = 0.000001f;

			for(k=m_PoseIdx;k<m_PoseIdx + m_NumPoses;k++)

				denom += attributes[lMIdx*m_NumAttributes + k];

			for(k=m_PoseIdx;k<m_PoseIdx + m_NumPoses;k++)

				attributes[lMIdx*m_NumAttributes + k] /= denom;

				

			if(rMIdx >= 0)

			{

				for(k=m_ExpressionIdx;k<m_ExpressionIdx + m_NumExpressions + m_NumPoses;k++)

					attributes[rMIdx*m_NumAttributes + k] *= m_RightAttr[rMIdx][k] + 0.0001f;



				denom = 0.000001f;

				for(k=m_ExpressionIdx;k<m_ExpressionIdx + m_NumExpressions;k++)

					denom += attributes[rMIdx*m_NumAttributes + k];

				for(k=m_ExpressionIdx;k<m_ExpressionIdx + m_NumExpressions;k++)

					attributes[rMIdx*m_NumAttributes + k] /= denom;



				denom = 0.000001f;

				for(k=m_PoseIdx;k<m_PoseIdx + m_NumPoses;k++)

					denom += attributes[rMIdx*m_NumAttributes + k];

				for(k=m_PoseIdx;k<m_PoseIdx + m_NumPoses;k++)

					attributes[rMIdx*m_NumAttributes + k] /= denom;



			}



			for(k=m_ClothingIdx;k<m_ClothingIdx + m_NumClothing;k++)

			{

				float ct = attributesCt[lMIdx*m_NumAttributes + k];

				attributes[lMIdx*m_NumAttributes + k] = (ct*attributes[lMIdx*m_NumAttributes + k] + m_LeftAttr[mMIdx][k])/(ct + 1.f);

				attributesCt[lMIdx*m_NumAttributes + k]++;



				if(rMIdx >= 0)

				{

					ct = attributesCt[rMIdx*m_NumAttributes + k];

					attributes[rMIdx*m_NumAttributes + k] = (ct*attributes[rMIdx*m_NumAttributes + k] + m_RightAttr[mMIdx][k])/(ct + 1.f);

					attributesCt[rMIdx*m_NumAttributes + k]++;

				}

			}

		}

			

	}

		

	for(j=0;j<tuples.size();j++)

	{

		int lIdx = tuples[j][0];

		int mIdx = tuples[j][1];

		int rIdx = tuples[j][2];




		int lMIdx = -1;
		if (lIdx>=0)
			lMIdx=m_NounMap[lIdx];

		int rMIdx = -1;
		if (rIdx>=0)
			rMIdx=m_NounMap[rIdx];

		int mMIdx = -1;
		if (mIdx>=0) 
			mMIdx= m_RelMap[mIdx];


		if(lMIdx >= 0)

			attributes[lMIdx*m_NumAttributes] = 1.f;



		if(rMIdx >= 0)

			attributes[rMIdx*m_NumAttributes] = 1.f;



		if(lMIdx >= 0 && rMIdx >= 0 && mMIdx >= 0)

		{

			for(k=0;k<NUM_GM_REL;k++)

			{

				attributes[lMIdx*m_NumAttributes + m_RelativeSpatialIdx + rMIdx*NUM_GM_REL + k] = m_RelAttr[mMIdx][k + 0*NUM_GM_REL];

				attributes[rMIdx*m_NumAttributes + m_RelativeSpatialIdx + lMIdx*NUM_GM_REL + k] = m_RelAttr[mMIdx][k + 1*NUM_GM_REL];

				attributes[lMIdx*m_NumAttributes + m_RelativeSpatialFlipIdx + rMIdx*NUM_GM_REL + k] = m_RelAttr[mMIdx][k + 2*NUM_GM_REL];

				attributes[rMIdx*m_NumAttributes + m_RelativeSpatialFlipIdx + lMIdx*NUM_GM_REL + k] = m_RelAttr[mMIdx][k + 3*NUM_GM_REL];

			}



			for(k=0;k<m_NumDepth;k++)

			{

				attributes[lMIdx*m_NumAttributes + m_RelativeDepthIdx + rMIdx*m_NumDepth + k] = m_RelAttr[mMIdx][k + 4*NUM_GM_REL];

				attributes[rMIdx*m_NumAttributes + m_RelativeDepthIdx + lMIdx*m_NumDepth + k] = m_RelAttr[mMIdx][k + 4*NUM_GM_REL + m_NumDepth];

			}



			if(lMIdx == 18 || lMIdx == 19)

			{

				attributes[lMIdx*m_NumAttributes + m_HandIdx + rMIdx] = m_RelAttr[mMIdx][4*NUM_GM_REL + 2*m_NumDepth];

			}

		}

		

			

	}

	//	for(j=0;j<m_NumExpressions;j++)

	//		printf("%d %f\n", j, attributes[19*m_NumAttributes + m_ExpressionIdx + j]);



	//	for(j=0;j<m_NumInstanceObj;j++)

	//		printf("%d %f  %f\n", j, attributes[18*m_NumAttributes + m_HeadIdx + j], attributes[19*m_NumAttributes + m_HeadIdx + j]);

	//	for(j=0;j<m_NumInstanceObj;j++)

	//		printf("%d %f\n", j, attributes[j*m_NumAttributes]);



	//	for(j=0;j<m_NumClothing;j++)

	//		printf("%d %f  %f\n", j, attributes[18*m_NumAttributes + m_ClothingIdx + j], attributes[19*m_NumAttributes + m_ClothingIdx + j]);



	

	//	for(j=0;j<m_NumDepth;j++)

	//		printf("%d %f\n", j, attributes[18*m_NumAttributes + m_RelativeDepthIdx + 29*m_NumDepth + j]);

	//	for(j=0;j<m_NumDepth;j++)

	//		printf("%d %f\n", j, attributes[19*m_NumAttributes + m_RelativeDepthIdx + 29*m_NumDepth + j]);

	//	for(j=0;j<m_NumDepth;j++)

	//		printf("%d %f\n", j, attributes[20*m_NumAttributes + m_RelativeDepthIdx + 29*m_NumDepth + j]);

	//	for(j=0;j<m_NumDepth;j++)

	//		printf("%d %f\n", j, attributes[21*m_NumAttributes + m_RelativeDepthIdx + 29*m_NumDepth + j]);

			

	delete [] attributesCt;

}



void CClipArt::LoadNounMap()

{

	int i, j, k;

	char name[1024];



	m_NounMap.resize(m_NumNouns);





	sprintf(name, "%sNounMI.txt", m_BaseName);

	printf("Reading %s\n", name);



	FILE *nin = fopen(name, "r");



	for(i=0;i<m_NumNouns;i++)

	{

		float scoreMI;

		fscanf(nin, "%d\t%d\t%f\n", &j, &k, &scoreMI);

		if(i!=8)
			m_NounMap[j] = k;
		else
			m_NounMap[j] = -1;
		

	}



	fclose(nin);



	printf("done.");

}



void CClipArt::RenderScenes()

{

	int i, j, k;

	float *attributes = new float [m_NumInstanceObj*m_NumAttributes];

	int ct = 0;

	int idx, val;

	vt::CRGBAImg outImg;

	outImg.Create(CANVAS_WIDTH, CANVAS_HEIGHT);
	
	char dumpster[10000];
	char dumpster_best[10000];

	int sceneCt = 0;

	vt::wstring wstr2(320);


//	FixNaming();

//	return;


	LoadAverageAttributes();
	LoadTuples();



//	for(i=start;i<end;i++)

	for(i=0;i<m_Tuple.size();i++)

	{
		printf("generating scene %d",i);
		UpdateAttributesWithTuples(attributes, m_Tuple[i]);



		float minScore = 1000000.f;

		ComputePDFs(attributes);



		for(j=0;j<3;j++)

		{

			float score = GenerateScene(attributes, outImg,dumpster,i);



			if(score < minScore)

			{

				//printf("Saving %sRenderingsTrash\\10K_Noun_%d_%d.png\n", m_BaseName, (m_TestingIdx + i)/3, (m_TestingIdx + i)%3);

				//wstr2.format(L"%SRenderingsTrash\\10K_Noun_%d_%d.png", m_BaseName, (m_TestingIdx + i)/3, (m_TestingIdx + i)%3);

				//VtSaveImage(wstr2, outImg);

				minScore = score;
				strcpy(dumpster_best,dumpster);

			}

		}
		//save the dumpster
		fprintf(stderr,"BEGIN\n");
		fprintf(stderr,"%s\n",dumpster_best);
		fprintf(stderr,"END\n");
		//fprintf(f_score,"%f\n",minScore);

	}


	/*

	while(fscanf(in, "%d", &ct) != EOF && sceneCt < 10)

	{

		memset(attributes, 0, m_NumInstanceObj*m_NumAttributes*sizeof(float));



		for(i=0;i<ct;i++)

		{

			fscanf(in, "%d", &idx);



			for(j=0;j<m_NumAttributes;j++)

			{

				fscanf(in, "%d", &val);

				attributes[idx*m_NumAttributes + j] = (float) val/255.f;

			}

		}



		for(j=0;j<5;j++)

		{

			for(k=0;k<m_NumInstanceObj*m_NumAttributes;k++)

				attributes[k] = m_AverageAttributes[k];



			GenerateScene(attributes, outImg);

			printf("Saving %s_%d_%d.png", baseName, sceneCt, j);

			wstr2.format(L"%S_%d_%d.png", baseName, sceneCt, j);

			VtSaveImage(wstr2, outImg);

		}



		sceneCt++;

	}

	*/



	delete [] attributes;



}



void CClipArt::SaveAverageAttributes()

{

	int i, j;

	float *attributes = new float [m_NumInstanceObj*m_NumAttributes];

	int ct = 0;

	vt::CRGBAImg outImg;

	float sceneCt = 0.f;

	int idx, val;



	FILE *in;

	char name[1024];

	sprintf(name, "%sAttributes_%d_%d_%d.txt", m_BaseName, NUM_GM_SPAT, NUM_GM_REL, m_NumAttributes);

	printf("Loading %s...", name);



	in = fopen(name, "r");



	memset(attributes, 0, m_NumInstanceObj*m_NumAttributes*sizeof(float));



	printf("Reading Attributes\n");



	while(fscanf(in, "%d", &ct) != EOF)

	{



		for(i=0;i<ct;i++)

		{

			fscanf(in, "%d", &idx);



			for(j=0;j<m_NumAttributes;j++)

			{

				fscanf(in, "%d", &val);

				attributes[idx*m_NumAttributes + j] += (float) val/255.f;

			}

		}



		sceneCt++;

	}



	fclose(in);

	printf("Loaded %f attributes\n",sceneCt);

	for(i=0;i<m_NumInstanceObj*m_NumAttributes;i++)

		attributes[i] /= sceneCt;



	FILE *out;

	sprintf(name, "%sAverageAttributes_%d.txt", m_BaseName, m_NumAttributes);

	printf("Saving %s...", name);



	out = fopen(name, "w");



	for(i=0;i<m_NumInstanceObj*m_NumAttributes;i++)

		fprintf(out, "%f\t", attributes[i]);



	fclose(out);

	printf("done.\n");



	delete [] attributes;

}



void CClipArt::LoadAverageAttributes()

{

	int i, j;

	m_AverageAttributes = new float [m_NumInstanceObj*m_NumAttributes];



	printf("Reading Average Attributes\n");

	FILE *in;

	char name[1024];

	sprintf(name, "%sAverageAttributes_%d.txt",m_BaseName, m_NumAttributes);

	printf("Loading %s...", name);



	in = fopen(name, "r");



	for(i=0;i<m_NumInstanceObj*m_NumAttributes;i++)

		fscanf(in, "%f\t", &(m_AverageAttributes[i]));



	fclose(in);

	printf("done.\n");

}







void CClipArt::Init()

{

	int i, j, k;


	printf("Init()");
	sprintf(m_BaseName, "./");

	m_NumNouns = 1133;

	m_NumRelations = 2379;

	m_NumScenes = 10020;

	m_ScaleFactor = 0.7f;

	m_NumInstanceObj = 58;

	m_NumDepth = 3;

	m_NumPoses = 7;

	m_NumExpressions = 5;

	m_NumClothing = 10;

	m_NumPersonAttrs = (m_NumExpressions + m_NumPoses + m_NumClothing);

	m_NumAttributes = 1 + NUM_GM_SPAT*m_NumDepth + m_NumInstanceObj + NUM_GM_REL*m_NumInstanceObj + NUM_GM_REL*m_NumInstanceObj + 3*m_NumInstanceObj + m_NumPersonAttrs + m_NumInstanceObj;

	m_NumClipArtDisplayed = 28;

	m_TestingIdx = 8000;



	m_AbsoluteSpatialIdx = 1;

	m_CoOccurrenceIdx = m_AbsoluteSpatialIdx + NUM_GM_SPAT*m_NumDepth;

	m_RelativeSpatialIdx = m_CoOccurrenceIdx + m_NumInstanceObj;

	m_RelativeSpatialFlipIdx = m_RelativeSpatialIdx + NUM_GM_REL*m_NumInstanceObj;

	m_RelativeDepthIdx = m_RelativeSpatialFlipIdx + NUM_GM_REL*m_NumInstanceObj;

	m_ExpressionIdx = m_RelativeDepthIdx + 3*m_NumInstanceObj;

	m_PoseIdx = m_ExpressionIdx + m_NumExpressions;

	m_ClothingIdx = m_PoseIdx + m_NumPoses;

	m_HandIdx = m_ClothingIdx + m_NumClothing;



	printf("AssignNames()");


	AssignNames();


	printf("Types");

	m_NumTypes = 8;

	m_TypeCt[0] = 8;

	m_TypeCt[1] = 10;

	m_TypeCt[2] = 35;

	m_TypeCt[3] = 35;

	m_TypeCt[4] = 6;

	m_TypeCt[5] = 10;

	m_TypeCt[6] = 7;

	m_TypeCt[7] = 15;


	printf("2d arrays");
	m_MapInstance = new int[8][35];

	m_HeadPos = new int[2][7][2];

	m_HandPos = new int[2][2][7][2];

	m_MapType = new int[m_NumInstanceObj];

	m_MapObject = new int[m_NumInstanceObj];

	m_GMM_mean_Spat = new float[m_NumDepth][2 * NUM_GM_SPAT];

	m_GMM_std_Spat = new float[m_NumDepth][2 * NUM_GM_SPAT];



	printf("2d arrays ops");


	m_HeadPos[0][0][0] = 49;

	printf("2d arrays ops 1");
	m_HeadPos[0][0][1] = 43;
	printf("2d arrays ops 2");

	m_HeadPos[0][1][0] = 60;
	printf("2d arrays ops 3");

	m_HeadPos[0][1][1] = 57;
	printf("2d arrays ops 4");

	m_HeadPos[0][2][0] = 67;

	m_HeadPos[0][2][1] = 43;

	m_HeadPos[0][3][0] = 55;

	m_HeadPos[0][3][1] = 43;

	m_HeadPos[0][4][0] = 91;

	m_HeadPos[0][4][1] = 43;

	m_HeadPos[0][5][0] = 85;

	m_HeadPos[0][5][1] = 43;

	m_HeadPos[0][6][0] = 54;

	m_HeadPos[0][6][1] = 43;



	m_HeadPos[1][0][0] = 60;

	m_HeadPos[1][0][1] = 39;

	m_HeadPos[1][1][0] = 65;

	m_HeadPos[1][1][1] = 39;

	m_HeadPos[1][2][0] = 61;

	m_HeadPos[1][2][1] = 39;

	m_HeadPos[1][3][0] = 68;

	m_HeadPos[1][3][1] = 39;

	m_HeadPos[1][4][0] = 82;

	m_HeadPos[1][4][1] = 39;

	m_HeadPos[1][5][0] = 79;

	m_HeadPos[1][5][1] = 39;

	m_HeadPos[1][6][0] = 82;

	m_HeadPos[1][6][1] = 39;



	for(i=0;i<7;i++)

	{

		m_HeadPos[0][i][0] -= 10;

		m_HeadPos[0][i][1] -= 36;

		m_HeadPos[1][i][0] -= 10;

		m_HeadPos[1][i][1] -= 38;

	}



	// Right hand boy

	m_HandPos[0][0][0][0] = 78;

	m_HandPos[0][0][0][1] = 107;

	m_HandPos[0][0][1][0] = 8;

	m_HandPos[0][0][1][1] = 11;

	m_HandPos[0][0][2][0] = 6;

	m_HandPos[0][0][2][1] = 125;

	m_HandPos[0][0][3][0] = 29;

	m_HandPos[0][0][3][1] = 110;

	m_HandPos[0][0][4][0] = 11;

	m_HandPos[0][0][4][1] = 115;

	m_HandPos[0][0][5][0] = 10;

	m_HandPos[0][0][5][1] = 113;

	m_HandPos[0][0][6][0] = 21;

	m_HandPos[0][0][6][1] = 118;



	// Left hand boy

	m_HandPos[0][1][0][0] = 97;

	m_HandPos[0][1][0][1] = 96;

	m_HandPos[0][1][1][0] = 107;

	m_HandPos[0][1][1][1] = 26;

	m_HandPos[0][1][2][0] = 103;

	m_HandPos[0][1][2][1] = 102;

	m_HandPos[0][1][3][0] = 91;

	m_HandPos[0][1][3][1] = 101;

	m_HandPos[0][1][4][0] = 144;

	m_HandPos[0][1][4][1] = 105;

	m_HandPos[0][1][5][0] = 117;

	m_HandPos[0][1][5][1] = 78;

	m_HandPos[0][1][6][0] = 109;

	m_HandPos[0][1][6][1] = 49;



	// Right hand girl

	m_HandPos[1][0][0][0] = 81;

	m_HandPos[1][0][0][1] = 103;

	m_HandPos[1][0][1][0] = 8;

	m_HandPos[1][0][1][1] = 17;

	m_HandPos[1][0][2][0] = 14;

	m_HandPos[1][0][2][1] = 116;

	m_HandPos[1][0][3][0] = 60;

	m_HandPos[1][0][3][1] = 104;

	m_HandPos[1][0][4][0] = 8;

	m_HandPos[1][0][4][1] = 33;

	m_HandPos[1][0][5][0] = 10;

	m_HandPos[1][0][5][1] = 111;

	m_HandPos[1][0][6][0] = 9;

	m_HandPos[1][0][6][1] = 33;



	// Left hand girl

	m_HandPos[1][1][0][0] = 108;

	m_HandPos[1][1][0][1] = 94;

	m_HandPos[1][1][1][0] = 107;

	m_HandPos[1][1][1][1] = 25;

	m_HandPos[1][1][2][0] = 97;

	m_HandPos[1][1][2][1] = 99;

	m_HandPos[1][1][3][0] = 106;

	m_HandPos[1][1][3][1] = 82;

	m_HandPos[1][1][4][0] = 130;

	m_HandPos[1][1][4][1] = 102;

	m_HandPos[1][1][5][0] = 112;

	m_HandPos[1][1][5][1] = 93;

	m_HandPos[1][1][6][0] = 131;

	m_HandPos[1][1][6][1] = 103;







	k = 0;

	for(i=0;i<8;i++)

	{

		for(j=0;j<m_TypeCt[i];j++)

		{

			m_MapInstance[i][j] = k;

			m_MapType[k] = i;

			m_MapObject[k] = j;



			if(i != 2 && i != 3)

			{

				k++;

			}

		}



		if(i == 2 || i == 3)

			k++;

	}


	printf("wh vectors");

	std::vector<std::vector<int> > wh0;

	std::vector<std::vector<int> > wh1;

	std::vector<std::vector<int> > wh2;

	std::vector<std::vector<int> > wh3;



	wh0.resize(m_NumTypes);

	wh1.resize(m_NumTypes);

	wh2.resize(m_NumTypes);

	wh3.resize(m_NumTypes);



	FILE *in;

	char name[1024];


	printf("base names");

	sprintf(name, "%sWHC.txt", m_BaseName);

	printf("Opening %s\n", name);

	in = fopen(name, "r");



    for (i = 0; i < m_NumTypes; i++) 

	{

		wh0[i].resize(2*m_TypeCt[i]);

		wh1[i].resize(2*m_TypeCt[i]);

		wh2[i].resize(2*m_TypeCt[i]);

		wh3[i].resize(2*m_TypeCt[i]);



        for (j = 0; j < 2*m_TypeCt[i]; j++)

			fscanf(in, "%d,", &(wh0[i][j]));

        for (j = 0; j < 2*m_TypeCt[i]; j++) 

			fscanf(in, "%d,", &(wh1[i][j]));

        for (j = 0; j < 2*m_TypeCt[i]; j++) 

			fscanf(in, "%d,", &(wh2[i][j]));

        for (j = 0; j < 2*m_TypeCt[i]; j++) 

			fscanf(in, "%d,", &(wh3[i][j]));

	}



	fclose(in);



	m_ClipArtW.resize(m_NumTypes);

	m_ClipArtH.resize(m_NumTypes);

	m_ClipArtC.resize(m_NumTypes);



    // Compute the bounding boxes for the clipart

    for (i = 0; i < m_NumTypes; i++) 

	{

		m_ClipArtW[i].resize(m_TypeCt[i]);

		m_ClipArtH[i].resize(m_TypeCt[i]);

		m_ClipArtC[i].resize(m_TypeCt[i]);



        for (j = 0; j < m_TypeCt[i]; j++) 

		{



			m_ClipArtW[i][j].resize(0);

			m_ClipArtH[i][j].resize(0);

			m_ClipArtC[i][j].resize(0);



            m_ClipArtW[i][j].push_back(wh0[i][j * 2]);

            m_ClipArtW[i][j].push_back(wh1[i][j * 2]);

            m_ClipArtW[i][j].push_back(wh2[i][j * 2]);

            m_ClipArtW[i][j].push_back(wh3[i][j * 2]);



			printf("%d ", wh0[i][j * 2]);



            m_ClipArtH[i][j].push_back(wh0[i][j * 2 + 1]);

            m_ClipArtH[i][j].push_back(wh1[i][j * 2 + 1]);

            m_ClipArtH[i][j].push_back(wh2[i][j * 2 + 1]);

            m_ClipArtH[i][j].push_back(wh3[i][j * 2 + 1]);



            m_ClipArtC[i][j].push_back(0);

            m_ClipArtC[i][j].push_back(m_ClipArtW[i][j][0]);

            m_ClipArtC[i][j].push_back(2 * m_ClipArtW[i][j][0]);

            m_ClipArtC[i][j].push_back(2 * m_ClipArtW[i][j][0] + m_ClipArtW[i][j][1]);

            m_ClipArtC[i][j].push_back(2 * m_ClipArtW[i][j][0] + 2 * m_ClipArtW[i][j][1]);

            m_ClipArtC[i][j].push_back(2 * m_ClipArtW[i][j][0] + 2 * m_ClipArtW[i][j][1] + m_ClipArtW[i][j][2]);

            m_ClipArtC[i][j].push_back(2 * m_ClipArtW[i][j][0] + 2 * m_ClipArtW[i][j][1] + 2 * m_ClipArtW[i][j][2]);

        }

    }



	// Fix the cat and dog flip problem...

	for(i=0;i<3;i++)

	{

		int c;

		c = m_ClipArtC[4][1][i*2];

		m_ClipArtC[4][1][i*2] = m_ClipArtC[4][1][i*2 + 1];

		m_ClipArtC[4][1][i*2 + 1] = c;



		c = m_ClipArtC[4][2][i*2];

		m_ClipArtC[4][2][i*2] = m_ClipArtC[4][2][i*2 + 1];

		m_ClipArtC[4][2][i*2 + 1] = c;

	}
	printf("Initialization finished");
}	



void CClipArt::SaveClipArtSingles()

{

	int i, j, r, c;

	vt::CRGBAImg img;

	vt::CRGBAImg outImg;

	vt::wstring wstr2(320);

		

	char (*prefix)[256] = new char [m_NumTypes][256];



	sprintf(prefix[0], "C:\\data\\Clipart\\Sentence2Scene\\pngs\\s");

	sprintf(prefix[1], "C:\\data\\Clipart\\Sentence2Scene\\pngs\\p");

	sprintf(prefix[2], "C:\\data\\Clipart\\Sentence2Scene\\pngs\\hb0");

	sprintf(prefix[3], "C:\\data\\Clipart\\Sentence2Scene\\pngs\\hb1");

	sprintf(prefix[4], "C:\\data\\Clipart\\Sentence2Scene\\pngs\\a");

	sprintf(prefix[5], "C:\\data\\Clipart\\Sentence2Scene\\pngs\\c");

	sprintf(prefix[6], "C:\\data\\Clipart\\Sentence2Scene\\pngs\\e");

	sprintf(prefix[7], "C:\\data\\Clipart\\Sentence2Scene\\pngs\\t");



    for (i = 0; i < m_NumTypes; i++) 

	{

		m_ClipArtW[i].resize(m_TypeCt[i]);

		m_ClipArtH[i].resize(m_TypeCt[i]);

		m_ClipArtC[i].resize(m_TypeCt[i]);



        for (j = 0; j < m_TypeCt[i]; j++) 

		{

			wstr2.format(L"%S_%d.png", prefix[i], j);

			//VtLoadImage(wstr2, img);



			outImg.Create(m_ClipArtW[i][j][0], m_ClipArtH[i][j][0]);



			if(i == 4 && (j == 1 || j == 2))

			{

				for(r=0;r<m_ClipArtH[i][j][0];r++)

					for(c=0;c<m_ClipArtW[i][j][0];c++)

					{

						outImg.Pix(c, r) = img.Pix(m_ClipArtW[i][j][0] - c - 1, r);

					}

			}

			else

			{

				for(r=0;r<m_ClipArtH[i][j][0];r++)

					for(c=0;c<m_ClipArtW[i][j][0];c++)

					{

						outImg.Pix(c, r) = img.Pix(c, r);

					}



			}



			wstr2.format(L"%S_%ds.png", prefix[i], j);

			//VtSaveImage(wstr2, outImg);

		}

	}



}



void CClipArt::SaveScenesTxt(std::vector<std::vector<int> > clipArtObjectIdx, std::vector<std::vector<int> > clipArtTypeIdx, 

							std::vector<std::vector<int> > clipArtX, std::vector<std::vector<int> > clipArtY, 

							std::vector<std::vector<int> > clipArtZ, std::vector<std::vector<int> > clipArtFlip, int numScenes)

{

	int i, j, k;

	FILE *out;

	char name[1024];

	int notUsed = -10000;



	char (*prefix)[256] = new char [m_NumTypes][256];

	sprintf(prefix[0], "s");

	sprintf(prefix[1], "p");

	sprintf(prefix[2], "hb0");

	sprintf(prefix[3], "hb1");

	sprintf(prefix[4], "a");

	sprintf(prefix[5], "c");

	sprintf(prefix[6], "e");

	sprintf(prefix[7], "t");



	int numSentences = 1002;

	

	int *cat2Sent = new int [numSentences];

	sprintf(name, "%ssentence_labels_1002.txt", m_BaseName);

	printf("Opening %s\n", name);

	FILE *in = fopen(name, "r");



	for(i=0;i<numSentences;i++)

	{

		float x;

		fscanf(in, "%f", &x);



		int idx = (int) (x + 0.1f) - 1;

		cat2Sent[idx] = i;

	//	cat2Sent[i] = idx;



	//	printf("%d ", sent2Cat[i]);

	}

	

	fclose(in);

	printf("dfgdfg\n");



	int *scene2Cat = new int [numSentences*10];

	sprintf(name, "%sscene_labels_10k.txt", m_BaseName);

	printf("Opening %s\n", name);

	in = fopen(name, "r");

	printf("dfgdfg\n");



	for(i=0;i<numSentences*10;i++)

	{

		float x;

		fscanf(in, "%f", &x);

		scene2Cat[i] = (int) (x + 0.1f) - 1;

	}

	

	fclose(in);





	char (*sceneName)[1024] = new char [numScenes][1024];

	sprintf(name, "SceneMap.txt");

	printf("Opening %s\n", name);

	in = fopen(name, "r");



	for(i=0;i<numSentences*10;i++)

	{

		char c;

		j = 0;



		fscanf(in, "%d", &k);

		fscanf(in, "%s", sceneName[i]);

		fscanf(in, "%s", name);

	}

	

	fclose(in);









	sprintf(name, "%sSceneData_%d.txt", m_BaseName, numScenes);

	out = fopen(name, "w");



	fprintf(out, "%d\n", numScenes);



	float depthScale[3];

	depthScale[0] = 1.f;

	depthScale[1] = 0.7f;

	depthScale[2] = 0.49f;



	FILE *out2;

	sprintf(name, "%sSceneMapV1_%d.txt", m_BaseName, numScenes);

	out2 = fopen(name, "w");



	for(k=0;k<numSentences;k++)

	for(i=0;i<numScenes;i++)

	{

		int cIdx = scene2Cat[i];

		int sIdx = cat2Sent[cIdx];



		if(sIdx == k)

		{

			int numClipArt = 0;

			for(j=0;j<clipArtTypeIdx[i].size();j++)

			{

				if(clipArtX[i][j] > notUsed)

					numClipArt++;

			}



			fprintf(out2, "%s\n", sceneName[i]);

			fprintf(out, "%d\t%d\n", k, numClipArt);



			for(j=0;j<clipArtTypeIdx[i].size();j++)

			{

				if(clipArtX[i][j] > notUsed)

				{

					fprintf(out, "%s_%ds.png\t%d\t%d\t", prefix[clipArtTypeIdx[i][j]], clipArtObjectIdx[i][j], clipArtTypeIdx[i][j], clipArtObjectIdx[i][j]);

					fprintf(out, "%d\t%d\t\%d\t%d\n", clipArtX[i][j], clipArtY[i][j], clipArtZ[i][j], clipArtFlip[i][j]);

				}

			}

		}



	}



	fclose(out2);

	fclose(out);

}




int CClipArt::ScanTuple(FILE *in, char *left, char *middle, char *right, char *sentence)

{

	int i;

	bool foundTuple = false;

	char c = 'q';

	int tupleIdx = 0;

	int idx = 0;

	i = 0;



	while (c != '\n')

	{

		fscanf(in, "%c", &c);



		if (c == '*')

			return 2;



		if (c != '\n' && c != 0 && c != '=')

		{

			sentence[i] = c;
				i++;

		}



		if (tupleIdx == 0 && c != ':')

		{

			if (c != 0 && c != ' ')

			{

				left[idx] = c;
					idx++;

			}

		}



		if (tupleIdx == 2 && c != '\n')

		{

			if (c != 0 && c != ' ')

			{

				middle[idx] = c;
				idx++;

			}

		}



		if (tupleIdx == 1 && c == ':')

		{

			tupleIdx = 2;

			idx = 0;



		}



		if (tupleIdx == 0 && c == ':')

		{

			tupleIdx = 1;

			foundTuple = true;

		}





	}



	sentence[i] = 0;



	if (foundTuple)

	{



		//	printf("%s %d\n", left, idx);

		//	printf("%s %d\n", middle, idx);

		middle[idx - 1] = 0;

		idx--;

		int last = idx;



		while (last > 0 && middle[last] != ':')

			last--;



		if (last > 0)

		{

			if ((middle[last - 1] == 'o') || (middle[last - 1] == 'c' && middle[last - 2] == 'o'))

			{

				for (i = last + 1; i<idx; i++)

				{

					right[i - (last + 1)] = middle[i];

				}



				last--;

				while (middle[last] != ':')

					last--;



				for (i = last; i<idx; i++)

					middle[i] = 0;

			}

		}



		return 1;

	}



	return 0;

}





bool CClipArt::IsSameWord(char *word0, char *word1)

{

	int i;



	//	printf("%s %s %d %d\n", word0, word1, strlen(word0), strlen(word1));

	if (strlen(word0) != strlen(word1))

		return false;



	for (i = 0; i<strlen(word0); i++)

		if (word0[i] != word1[i])

			return false;



	return true;

}





void CClipArt::ParseTuples()

{

	int i, j, k, l;

	FILE *inNames;

	char name[1024];

	char(*nameArray)[50] = new char[m_NumScenes][50];

	FILE *inTuple;


	if (true)
	{
		FILE *out;

		sprintf(name, "%sSceneMap.txt", m_BaseName);

		out = fopen(name, "w");



		for (i = 0; i < 3000; i++)

		{

			fprintf(out, "%d\tS2S_Final_0_%d_%d\t10K_%d_%d\n", i, i / 3, i % 3, i / 3, i % 3);

		}



		for (i = 0; i < 7020; i++)

		{

			fprintf(out, "%d\t7K_%d_%d\t10K_%d_%d\n", i + 3000, i / 3, i % 3, (i + 3000) / 3, (i + 3000) % 3);

		}



		fclose(out);

	}

	sprintf(name, "%sSceneMap.txt", m_BaseName);

	inNames = fopen(name, "r");



	for (i = 0; i<m_NumScenes; i++)

	{

		fscanf(inNames, "%d\t%s\t%s\n", &j, nameArray[i], name);

	}



	fclose(inNames);



	char(*nouns)[100] = new char[50000][100];

	char(*relations)[100] = new char[50000][100];

	int *nounCt = new int[50000];

	int *relationCt = new int[50000];

	char Verb[10];

	char c;

	char left[100], middle[100], right[100], sentence[1024];

	int nounIdx = 0;

	int relationIdx = 0;



	memset(nounCt, 0, 50000 * sizeof(int));

	memset(relationCt, 0, 50000 * sizeof(int));

	sprintf(Verb, "Verb");



	FILE *tupleOut;

	sprintf(name, "%sTuples.txt", m_BaseName);

	tupleOut = fopen(name, "w");



	for (i = 0; i<m_NumScenes; i++)

	{

		sprintf(name, "%stuples/output/%s.out", m_BaseName, nameArray[i]);



		printf("Opening %s\n", name);



		inTuple = fopen(name, "r");

		int status = 1;



		while (status != 2)

		{

			memset(left, 0, 100 * sizeof(char));

			memset(middle, 0, 100 * sizeof(char));

			memset(right, 0, 100 * sizeof(char));



			status = ScanTuple(inTuple, left, middle, right, sentence);



			if (status == 1)

			{

					printf("L: %s\n", left);

					printf("M: %s\n", middle);

					printf("R: %s\n", right);



				if (!IsSameWord(left, Verb) && !IsSameWord(right, Verb))

				{

					int lIdx, rIdx, mIdx;

					bool found = false;



					for (j = 0; j<nounIdx; j++)

					{

						if (IsSameWord(left, &(nouns[j][0])))

						{

							lIdx = j;

							found = true;

						}

					}



					if (!found)

					{

						sprintf(&(nouns[nounIdx][0]), "%s", left);

						lIdx = nounIdx;

						nounIdx++;

					}



					found = false;

					for (j = 0; j<nounIdx; j++)

					{

						if (IsSameWord(right, &(nouns[j][0])))

						{

							rIdx = j;

							found = true;

						}

					}



					if (!found)

					{

						sprintf(&(nouns[nounIdx][0]), "%s", right);

						rIdx = nounIdx;

						nounIdx++;

					}



					found = false;

					for (j = 0; j<relationIdx; j++)

					{

						if (IsSameWord(middle, relations[j]))

						{

							mIdx = j;

							found = true;

						}

					}



					if (!found)

					{

						sprintf(relations[relationIdx], "%s", middle);

						mIdx = relationIdx;

						relationIdx++;

					}



					nounCt[lIdx]++;

					nounCt[rIdx]++;

					relationCt[mIdx]++;



					fprintf(tupleOut, "%d\t%d\t%d\t%d\n", i, lIdx, mIdx, rIdx);

				}

			}

		}



		fclose(inTuple);

	}





	for (i = 0; i<m_NumScenes; i++)

	{

		sprintf(name, "%stuples/batch2/%s.out", m_BaseName, nameArray[i]);



		printf("Opening %s\n", name);



		inTuple = fopen(name, "r");

		int status = 1;



		while (status != 2)

		{

			memset(left, 0, 100 * sizeof(char));

			memset(middle, 0, 100 * sizeof(char));

			memset(right, 0, 100 * sizeof(char));



			status = ScanTuple(inTuple, left, middle, right, sentence);



			if (status == 1)

			{

					printf("L: %s\n", left);

					printf("M: %s\n", middle);

					printf("R: %s\n", right);



				if (!IsSameWord(left, Verb) && !IsSameWord(right, Verb))

				{

					int lIdx, rIdx, mIdx;

					bool found = false;



					for (j = 0; j<nounIdx; j++)

					{

						if (IsSameWord(left, &(nouns[j][0])))

						{

							lIdx = j;

							found = true;

						}

					}



					if (!found)

					{
						sprintf(&(nouns[nounIdx][0]), "%s", left);

						lIdx = nounIdx;

						nounIdx++;

					}



					found = false;

					for (j = 0; j<nounIdx; j++)

					{

						if (IsSameWord(right, &(nouns[j][0])))

						{

							rIdx = j;

							found = true;

						}

					}



					if (!found)

					{

						sprintf(&(nouns[nounIdx][0]), "%s", right);

						rIdx = nounIdx;

						nounIdx++;

					}



					found = false;

					for (j = 0; j<relationIdx; j++)

					{

						if (IsSameWord(middle, relations[j]))

						{

							mIdx = j;

							found = true;

						}

					}



					if (!found)

					{

						sprintf(relations[relationIdx], "%s", middle);

						mIdx = relationIdx;

						relationIdx++;

					}



					nounCt[lIdx]++;

					nounCt[rIdx]++;

					relationCt[mIdx]++;



					fprintf(tupleOut, "%d\t%d\t%d\t%d\n", i, lIdx, mIdx, rIdx);

				}

			}

		}



		fclose(inTuple);

	}





	fclose(tupleOut);



	FILE *out;



	sprintf(name, "%sRelationsMap.txt", m_BaseName);

	out = fopen(name, "w");



	for (i = 0; i<relationIdx; i++)

	{

		fprintf(out, "%d\t%d\t%s\n", i, relationCt[i], relations[i]);

	}



	fclose(out);



	sprintf(name, "%sNounsMap.txt", m_BaseName);

	out = fopen(name, "w");



	for (i = 0; i<nounIdx; i++)

	{

		fprintf(out, "%d\t%d\t%s\n", i, nounCt[i], nouns[i]);

	}



	fclose(out);


	printf("ParseTuple: Done.");


	delete[] nameArray;

}



void CClipArt::ComputeNounTupleMI()

{

	FILE *in;

	char name[1024];

	float *occ = new float[m_NumScenes*m_NumInstanceObj];

	float *noun = new float[m_NumScenes*m_NumNouns];

	int i, j, k, l, lIdx, mIdx, rIdx;



	memset(noun, 0, m_NumScenes*m_NumNouns*sizeof(int));

	memset(occ, 0, m_NumScenes*m_NumInstanceObj*sizeof(int));



	sprintf(name, "%sTuples.txt", m_BaseName);

	in = fopen(name, "r");



	while (fscanf(in, "%d", &i) != EOF)

	{

		fscanf(in, "%d\t%d\t%d", &lIdx, &mIdx, &rIdx);



		noun[i*m_NumNouns + lIdx] = 1.f;

		noun[i*m_NumNouns + rIdx] = 1.f;

	}



	fclose(in);



	sprintf(name, "%sAttributes_%d_%d_%d.txt", m_BaseName, NUM_GM_SPAT, NUM_GM_REL, m_NumAttributes);

	in = fopen(name, "r");

	int ct;



	for (i = 0; i<m_TestingIdx; i++)

	{

		fscanf(in, "%d", &ct);

		for (j = 0; j<ct; j++)

		{

			fscanf(in, "%d", &k);



			occ[i*m_NumInstanceObj + k] = 1.f;



			for (k = 0; k<m_NumAttributes; k++)

				fscanf(in, "%d", &l);

		}

	}



	fclose(in);



	FILE *out;

	sprintf(name, "%sNounMI.txt", m_BaseName);

	printf("Writing %s\n", name);

	out = fopen(name, "w");



	for (i = 0; i<m_NumNouns; i++)

	{

		int maxObj = -1;

		float maxMI = 0.f;



		for (j = 0; j<m_NumInstanceObj; j++)

		{

			float MI = 0.f;



			float pF = 0.f;

			float pW = 0.f;

			float pFW = 0.f;

			float pnFW = 0.f;

			float pFnW = 0.f;

			float pnFnW = 0.f;



			for (k = 0; k<m_TestingIdx; k++)

			{

				float w = noun[k*m_NumNouns + i];

				float f = occ[k*m_NumInstanceObj + j];



				pF += f;

				pW += w;

				pFW += f*w;

				pnFW += (1.f - f)*w;

				pFnW += f*(1.f - w);

				pnFnW += (1.f - f)*(1.f - w);

			}



			pF /= (float)m_TestingIdx;

			pW /= (float)m_TestingIdx;

			pFW /= (float)m_TestingIdx;

			pnFW /= (float)m_TestingIdx;

			pFnW /= (float)m_TestingIdx;

			pnFnW /= (float)m_TestingIdx;



			if (pFW > 0.000001f)

				MI += pFW*log(pFW / (pF*pW));

			if (pnFW > 0.000001f)

				MI += pnFW*log(pnFW / ((1.f - pF)*pW));

			if (pFnW > 0.000001f)

				MI += pFnW*log(pFnW / (pF*(1.f - pW)));

			if (pnFnW > 0.000001f)

				MI += pnFnW*log(pnFnW / ((1.f - pF)*(1.f - pW)));



			MI /= log(2.f);



			if (MI > maxMI)

			{

				maxMI = MI;

				maxObj = j;

			}

			//	fprintf(out, "%f\t", MI);



		}



		fprintf(out, "%d\t%d\t%f\n", i, maxObj, maxMI);

		//	fprintf(out, "\n");

	}



	fclose(out);

}



void CClipArt::ComputeMeanTupleAttribute()

{

	int i, j, k, l;

	FILE *in;

	char name[1024];

	int *nounMap = new int[m_NumNouns];

	int *nounCt = new int[m_NumNouns];

	int *left = new int[m_NumScenes * 10];

	int *right = new int[m_NumScenes * 10];

	int *middle = new int[m_NumScenes * 10];

	int *sceneIdx = new int[m_NumScenes * 10];

	int lIdx, rIdx, mIdx;

	int numTuples = 0;



	sprintf(name, "%sNounMI.txt", m_BaseName);

	in = fopen(name, "r");



	for (i = 0; i<m_NumNouns; i++)

	{

		float scoreMI;

		fscanf(in, "%d\t%d\t%f\n", &j, &k, &scoreMI);
		//hax to get rid of the snake
		if (i!=8)
			nounMap[j] = k;
		else
			nounMap[j] = -1;

	}



	fclose(in);



	sprintf(name, "%sTuples.txt", m_BaseName);

	in = fopen(name, "r");



	while (fscanf(in, "%d", &i) != EOF)

	{

		fscanf(in, "%d\t%d\t%d", &lIdx, &mIdx, &rIdx);



		if (i < m_TestingIdx)

		{

			sceneIdx[numTuples] = i;

			left[numTuples] = lIdx;

			middle[numTuples] = mIdx;

			right[numTuples] = rIdx;

			numTuples++;

		}

	}



	fclose(in);



	printf("Number of Tuples = %d\n", numTuples);



	std::vector<std::vector<std::vector<float> > > attributes;

	std::vector<std::vector<int> > objIdx;

	attributes.resize(m_NumScenes);

	objIdx.resize(m_NumScenes);

	sprintf(name, "%sAttributes_%d_%d_%d.txt", m_BaseName, NUM_GM_SPAT, NUM_GM_REL, m_NumAttributes);

	in = fopen(name, "r");

	int ct;



	for (i = 0; i<m_TestingIdx; i++)

	{

		fscanf(in, "%d", &ct);

		attributes[i].resize(ct);

		objIdx[i].resize(ct);



		for (j = 0; j<ct; j++)

		{

			attributes[i][j].resize(0);



			fscanf(in, "%d", &k);



			objIdx[i][j] = k;



			for (k = 0; k<m_NumAttributes; k++)

			{

				fscanf(in, "%d", &l);

				attributes[i][j].push_back((float)l / 255.f);

			}

		}

	}



	fclose(in);



	int numRelAttr = (2 * NUM_GM_REL + 2 * NUM_GM_REL + 2 * 3 + 1);

	float *leftAttr = new float[m_NumAttributes];

	float *rightAttr = new float[m_NumAttributes];

	float *relAttr = new float[numRelAttr];

	float relCt;

	float relLeftCt;

	FILE *out;



	sprintf(name, "%sMeanRelationAttributes_%d.txt", m_BaseName, m_NumAttributes);

	out = fopen(name, "w");



	vt::CRGBAImg outImg;

	outImg.Create(CANVAS_WIDTH, CANVAS_HEIGHT);



	for (i = 0; i<m_NumRelations; i++)

	{

		memset(leftAttr, 0, m_NumAttributes*sizeof(float));

		memset(rightAttr, 0, m_NumAttributes*sizeof(float));

		memset(relAttr, 0, (numRelAttr)*sizeof(float));

		relCt = 0.f;

		relLeftCt = 0.f;



		for (j = 0; j<numTuples; j++)

		{

			if (middle[j] == i)

			{

				lIdx = nounMap[left[j]];

				rIdx = nounMap[right[j]];

				int sIdx = sceneIdx[j];



				int rMIdx = -1;

				int lMIdx = -1;



				for (k = 0; k<objIdx[sIdx].size(); k++)

				{

					if (objIdx[sIdx][k] == lIdx)

						lMIdx = k;

					if (objIdx[sIdx][k] == rIdx)

						rMIdx = k;

				}



				if (lMIdx >= 0 && rMIdx >= 0)

				{

					for (k = 0; k<m_NumAttributes; k++)

					{

						rightAttr[k] += attributes[sIdx][rMIdx][k];

					}



					for (k = 0; k<NUM_GM_REL; k++)

					{

						relAttr[k + 0 * NUM_GM_REL] += attributes[sIdx][lMIdx][m_RelativeSpatialIdx + rIdx*NUM_GM_REL + k];

						relAttr[k + 1 * NUM_GM_REL] += attributes[sIdx][rMIdx][m_RelativeSpatialIdx + lIdx*NUM_GM_REL + k];

						relAttr[k + 2 * NUM_GM_REL] += attributes[sIdx][lMIdx][m_RelativeSpatialFlipIdx + rIdx*NUM_GM_REL + k];

						relAttr[k + 3 * NUM_GM_REL] += attributes[sIdx][rMIdx][m_RelativeSpatialFlipIdx + lIdx*NUM_GM_REL + k];

					}



					for (k = 0; k<m_NumDepth; k++)

					{

						relAttr[k + 4 * NUM_GM_REL] += attributes[sIdx][lMIdx][m_RelativeDepthIdx + rIdx*m_NumDepth + k];

						relAttr[k + 4 * NUM_GM_REL + m_NumDepth] += attributes[sIdx][rMIdx][m_RelativeDepthIdx + lIdx*m_NumDepth + k];

					}



					relAttr[4 * NUM_GM_REL + 2 * m_NumDepth] += attributes[sIdx][lMIdx][m_HandIdx + rIdx];



					relCt++;

				}



				if (lMIdx >= 0)

				{

					for (k = 0; k<m_NumAttributes; k++)

					{

						leftAttr[k] += attributes[sIdx][lMIdx][k];

					}



					relLeftCt++;

				}

			}

		}



		printf("%d %f %f\n", i, relLeftCt, relCt);



		if (relLeftCt > 5.f)

		{

			for (j = 0; j<m_NumAttributes; j++)

			{

				leftAttr[j] /= relLeftCt;



				if (relCt > 0.f)

					rightAttr[j] /= relCt;

			}



			if (relCt > 0.f)

				for (j = 0; j<(numRelAttr); j++)

					relAttr[j] /= relCt;



			fprintf(out, "%d\t", i);

			for (j = 0; j<m_NumAttributes; j++)

				fprintf(out, "%f\t", leftAttr[j]);

			for (j = 0; j<m_NumAttributes; j++)

				fprintf(out, "%f\t", rightAttr[j]);

			for (j = 0; j<(numRelAttr); j++)

				fprintf(out, "%f\t", relAttr[j]);



			fprintf(out, "\n");

		}

		/*

		int r, c;

		float prob[NUM_GM_REL];

		vt::wstring wstr2(320);





		for(r=0;r<CANVAS_HEIGHT;r++)

		for(c=0;c<CANVAS_WIDTH;c++)

		{

		float x = 2.f*((float) c - CANVAS_WIDTH/2.f) + CANVAS_WIDTH/2;

		float y = 2.f*((float) r - CANVAS_HEIGHT/2.f) + CANVAS_HEIGHT/2;

		float pos[2];



		memset(prob, 0, NUM_GM_REL*sizeof(float));

		ComputeRelativePosition(CANVAS_WIDTH/2.f, x, CANVAS_HEIGHT/2.f, y, 0, pos, 0);

		ComputeGMMProbs(pos, m_GMM_mean_Rel, m_GMM_std_Rel, prob, NUM_GM_REL);



		float sum = 0.f;

		for(j=0;j<NUM_GM_REL;j++)

		{

		sum += prob[j]*relAttr[j];

		}



		outImg.Pix(c, r).r = (int) min(255.f, 2550.f*sum);

		outImg.Pix(c, r).g = (int) min(255.f, 25500.f*sum);

		outImg.Pix(c, r).b = (int) min(255.f, 255000.f*sum);

		//outImg.Pix(c, r).b = 80;//(int) min(255.f, 25500000.f*sum);

		outImg.Pix(c, r).a = 255;

		}



		wstr2.format(L"%SAttributeVisualize\\%d_RelativeSpatialLR.png", m_BaseName, i);

		VtSaveImage(wstr2, outImg);



		for(r=0;r<CANVAS_HEIGHT;r++)

		for(c=0;c<CANVAS_WIDTH;c++)

		{

		float x = 2.f*((float) c - CANVAS_WIDTH/2.f) + CANVAS_WIDTH/2;

		float y = 2.f*((float) r - CANVAS_HEIGHT/2.f) + CANVAS_HEIGHT/2;

		float pos[2];



		memset(prob, 0, NUM_GM_REL*sizeof(float));

		ComputeRelativePosition(CANVAS_WIDTH/2.f, x, CANVAS_HEIGHT/2.f, y, 0, pos, 0);

		ComputeGMMProbs(pos, m_GMM_mean_Rel, m_GMM_std_Rel, prob, NUM_GM_REL);



		float sum = 0.f;

		for(j=0;j<NUM_GM_REL;j++)

		{

		sum += prob[j]*relAttr[j + NUM_GM_REL];

		}



		outImg.Pix(c, r).r = (int) min(255.f, 2550.f*sum);

		outImg.Pix(c, r).g = (int) min(255.f, 25500.f*sum);

		outImg.Pix(c, r).b = (int) min(255.f, 255000.f*sum);

		//outImg.Pix(c, r).b = 80;//(int) min(255.f, 25500000.f*sum);

		outImg.Pix(c, r).a = 255;

		}



		wstr2.format(L"%SAttributeVisualize\\%d_RelativeSpatialRL.png", m_BaseName, i);

		VtSaveImage(wstr2, outImg);



		for(r=0;r<CANVAS_HEIGHT;r++)

		for(c=0;c<CANVAS_WIDTH;c++)

		{

		float x = 2.f*((float) c - CANVAS_WIDTH/2.f) + CANVAS_WIDTH/2;

		float y = 2.f*((float) r - CANVAS_HEIGHT/2.f) + CANVAS_HEIGHT/2;

		float pos[2];



		memset(prob, 0, NUM_GM_REL*sizeof(float));

		ComputeRelativePosition(CANVAS_WIDTH/2.f, x, CANVAS_HEIGHT/2.f, y, 0, pos, 1);

		ComputeGMMProbs(pos, m_GMM_mean_RelFlip, m_GMM_std_RelFlip, prob, NUM_GM_REL);



		float sum = 0.f;

		for(j=0;j<NUM_GM_REL;j++)

		sum += prob[j]*relAttr[j + 2*NUM_GM_REL];



		outImg.Pix(c, r).r = (int) min(255.f, 2550.f*sum);

		outImg.Pix(c, r).g = (int) min(255.f, 25500.f*sum);

		outImg.Pix(c, r).b = (int) min(255.f, 255000.f*sum);

		outImg.Pix(c, r).a = 255;

		}



		wstr2.format(L"%SAttributeVisualize\\%d_RelativeSpatialFlipLR.png", m_BaseName, i);

		VtSaveImage(wstr2, outImg);



		for(r=0;r<CANVAS_HEIGHT;r++)

		for(c=0;c<CANVAS_WIDTH;c++)

		{

		float x = 2.f*((float) c - CANVAS_WIDTH/2.f) + CANVAS_WIDTH/2;

		float y = 2.f*((float) r - CANVAS_HEIGHT/2.f) + CANVAS_HEIGHT/2;

		float pos[2];



		memset(prob, 0, NUM_GM_REL*sizeof(float));

		ComputeRelativePosition(CANVAS_WIDTH/2.f, x, CANVAS_HEIGHT/2.f, y, 0, pos, 1);

		ComputeGMMProbs(pos, m_GMM_mean_RelFlip, m_GMM_std_RelFlip, prob, NUM_GM_REL);



		float sum = 0.f;

		for(j=0;j<NUM_GM_REL;j++)

		sum += prob[j]*relAttr[j + 3*NUM_GM_REL];



		outImg.Pix(c, r).r = (int) min(255.f, 2550.f*sum);

		outImg.Pix(c, r).g = (int) min(255.f, 25500.f*sum);

		outImg.Pix(c, r).b = (int) min(255.f, 255000.f*sum);

		outImg.Pix(c, r).a = 255;

		}



		wstr2.format(L"%SAttributeVisualize\\%d_RelativeSpatialFlipRL.png", m_BaseName, i);

		VtSaveImage(wstr2, outImg);

		*/



	}



	fclose(out);



}



void CClipArt::LoadMeanAttributes()

{

	int i, j, idx;

	char name[1024];

	FILE *in;

	int numRelAttr = (2 * NUM_GM_REL + 2 * NUM_GM_REL + 2 * 3 + 1);



	sprintf(name, "%sMeanRelationAttributes_%d.txt", m_BaseName, m_NumAttributes);

	printf("Reading %s\n", name);

	in = fopen(name, "r");



	m_RelMap.resize(m_NumRelations);

	for (i = 0; i<m_NumRelations; i++)

		m_RelMap[i] = -1;



	i = 0;

	while (fscanf(in, "%d\t", &idx) != EOF)

	{

		m_RelMap[idx] = i;



		std::vector<float> leftAttr;

		leftAttr.resize(m_NumAttributes);



		std::vector<float> rightAttr;

		rightAttr.resize(m_NumAttributes);



		std::vector<float> relAttr;

		relAttr.resize(numRelAttr);



		for (j = 0; j<m_NumAttributes; j++)

			fscanf(in, "%f\t", &(leftAttr[j]));

		for (j = 0; j<m_NumAttributes; j++)

			fscanf(in, "%f\t", &(rightAttr[j]));

		for (j = 0; j<numRelAttr; j++)

			fscanf(in, "%f\t", &(relAttr[j]));



		m_LeftAttr.push_back(leftAttr);

		m_RightAttr.push_back(rightAttr);

		m_RelAttr.push_back(relAttr);



		i++;

	}



	fclose(in);

}


void CClipArt::SaveSceneTuples()

{

	int i, j, k, l;

	FILE *inNames;

	char name[1024];

	char (*nameArray)[50] = new char [m_NumScenes][50]; 

	FILE *inTuple;



	sprintf(name, "%sSceneMapV1_10020.txt", m_BaseName);

	inNames = fopen(name, "r");

	

	for(i=0;i<m_NumScenes;i++)

	{

		fscanf(inNames, "%s\n",nameArray[i]);

	}



	fclose(inNames);



	char (*nouns)[100] = new char [50000][100];

	char (*relations)[100] = new char [50000][100];

	int *nounCt = new int [50000];

	int *relationCt = new int [50000];

	char Verb[10];

	char c;

	char left[100], middle[100], right[100], sentence[1024];

	int nounIdx = 0;

	int relationIdx = 0;



	memset(nounCt, 0, 50000*sizeof(int));

	memset(relationCt, 0, 50000*sizeof(int));

	sprintf(Verb, "Verb");



	printf("Writing\n");

	FILE *sentOut;

	sprintf(name, "%sSimpleSentences1_%d.txt", m_BaseName, m_NumScenes);

	sentOut = fopen(name, "w");



	FILE *tupleTextOut;

	sprintf(name, "%sTuplesText1_%d.txt", m_BaseName, m_NumScenes);

	tupleTextOut = fopen(name, "w");



	FILE *tupleOut;

	sprintf(name, "%sTuplesIdx1_%d.txt", m_BaseName, m_NumScenes);

	tupleOut = fopen(name, "w");



	for(i=0;i<m_NumScenes;i++)

	{

		sprintf(name, "%stuples/output/%s.out", m_BaseName, nameArray[i]);



		printf("Opening %s\n", name);



		inTuple = fopen(name, "r");

		int status = 1;

		int sentIdx = -1;



		while(status != 2)

		{

			memset(left, 0, 100*sizeof(char));

			memset(middle, 0, 100*sizeof(char));

			memset(right, 0, 100*sizeof(char));

			memset(sentence, 0, 1024*sizeof(char));



			status = ScanTuple(inTuple, left, middle, right, sentence);

			if(status == 0)

			{

				if(strlen(sentence) > 3)

				{

					sentIdx++;

					fprintf(sentOut, "%d\t%d\t%s\n", i, sentIdx, sentence);

					printf("%s\n", sentence);

				}

			}



			if(status == 1)

			{



			//	printf("L: %s\n", left);

			//	printf("M: %s\n", middle);

			//	printf("R: %s\n", right);

				



				if(!IsSameWord(left, Verb) && !IsSameWord(right, Verb))

				{

					fprintf(tupleTextOut, "%d\t%d\t%s\t%s\t%s\n", i, sentIdx, left, middle, right);

					int lIdx, rIdx, mIdx;

					bool found = false;



					for(j=0;j<nounIdx;j++)

					{

						if(IsSameWord(left, &(nouns[j][0])))

						{

							lIdx = j;

							found = true;

						}

					}



					if(!found)

					{

						sprintf(&(nouns[nounIdx][0]), "%s", left);

						lIdx = nounIdx;

						nounIdx++;

					}



					found = false;

					for(j=0;j<nounIdx;j++)

					{

						if(IsSameWord(right, &(nouns[j][0])))

						{

							rIdx = j;

							found = true;

						}

					}



					if(!found)

					{

						sprintf(&(nouns[nounIdx][0]), "%s", right);

						rIdx = nounIdx;

						nounIdx++;

					}



					found = false;

					for(j=0;j<relationIdx;j++)

					{

						if(IsSameWord(middle, relations[j]))

						{

							mIdx = j;

							found = true;

						}

					}



					if(!found)

					{

						sprintf(relations[relationIdx], "%s", middle);

						mIdx = relationIdx;

						relationIdx++;

					}



					nounCt[lIdx]++;

					nounCt[rIdx]++;

					relationCt[mIdx]++;



					fprintf(tupleOut, "%d\t%d\t%d\t%d\t%d\n", i, sentIdx, lIdx, mIdx, rIdx);

				}

			}

		}



		fclose(inTuple);

	}



	fclose(sentOut);

	fclose(tupleOut);

	fclose(tupleTextOut);



	printf("Writing\n");

	sprintf(name, "%sSimpleSentences2_%d.txt", m_BaseName, m_NumScenes);

	sentOut = fopen(name, "w");



	sprintf(name, "%sTuplesText2_%d.txt", m_BaseName, m_NumScenes);

	tupleTextOut = fopen(name, "w");



	sprintf(name, "%sTuplesIdx2_%d.txt", m_BaseName, m_NumScenes);

	tupleOut = fopen(name, "w");



	for(i=0;i<m_NumScenes;i++)

	{

		sprintf(name, "%stuples/batch2/%s.out", m_BaseName, nameArray[i]);



	//	printf("Opening %s\n", name);



		inTuple = fopen(name, "r");

		int status = 1;

		int sentIdx = -1;



		while(status != 2)

		{

			memset(left, 0, 100*sizeof(char));

			memset(middle, 0, 100*sizeof(char));

			memset(right, 0, 100*sizeof(char));

			memset(sentence, 0, 1024*sizeof(char));



			status = ScanTuple(inTuple, left, middle, right, sentence);

			if(status == 0)

			{

				if(strlen(sentence) > 3)

				{

					sentIdx++;

					fprintf(sentOut, "%d\t%d\t%s\n", i, sentIdx, sentence);

					printf("%s\n", sentence);

				}

			}



			if(status == 1)

			{



			//	printf("L: %s\n", left);

			//	printf("M: %s\n", middle);

			//	printf("R: %s\n", right);

				



				if(!IsSameWord(left, Verb) && !IsSameWord(right, Verb))

				{

					fprintf(tupleTextOut, "%d\t%d\t%s\t%s\t%s\n", i, sentIdx, left, middle, right);

					int lIdx, rIdx, mIdx;

					bool found = false;



					for(j=0;j<nounIdx;j++)

					{

						if(IsSameWord(left, &(nouns[j][0])))

						{

							lIdx = j;

							found = true;

						}

					}



					if(!found)

					{

						sprintf(&(nouns[nounIdx][0]), "%s", left);

						lIdx = nounIdx;

						nounIdx++;

					}



					found = false;

					for(j=0;j<nounIdx;j++)

					{

						if(IsSameWord(right, &(nouns[j][0])))

						{

							rIdx = j;

							found = true;

						}

					}



					if(!found)

					{

						sprintf(&(nouns[nounIdx][0]), "%s", right);

						rIdx = nounIdx;

						nounIdx++;

					}



					found = false;

					for(j=0;j<relationIdx;j++)

					{

						if(IsSameWord(middle, relations[j]))

						{

							mIdx = j;

							found = true;

						}

					}



					if(!found)

					{

						sprintf(relations[relationIdx], "%s", middle);

						mIdx = relationIdx;

						relationIdx++;

					}



					nounCt[lIdx]++;

					nounCt[rIdx]++;

					relationCt[mIdx]++;



					fprintf(tupleOut, "%d\t%d\t%d\t%d\t%d\n", i, sentIdx, lIdx, mIdx, rIdx);

				}

			}

		}



		fclose(inTuple);

	}



	fclose(sentOut);

	fclose(tupleOut);

	fclose(tupleTextOut);

	/*

	printf("Writing\n");

	sprintf(name, "%sSimpleSentences3_%d.txt", m_BaseName, m_NumScenes);

	sentOut = fopen(name, "w");



	sprintf(name, "%sTuplesText3_%d.txt", m_BaseName, m_NumScenes);

	tupleTextOut = fopen(name, "w");



	sprintf(name, "%sTuplesIdx3_%d.txt", m_BaseName, m_NumScenes);

	tupleOut = fopen(name, "w");



	for(i=0;i<m_NumScenes;i++)

	{

		sprintf(name, "%stuples\\out-6-7-2013\\%s.out", m_BaseName, nameArray[i]);



	//	printf("Opening %s\n", name);



		inTuple = fopen(name, "r");

		int status = 1;

		int sentIdx = -1;



		while(status != 2)

		{

			memset(left, 0, 100*sizeof(char));

			memset(middle, 0, 100*sizeof(char));

			memset(right, 0, 100*sizeof(char));

			memset(sentence, 0, 1024*sizeof(char));



			status = ScanTuple(inTuple, left, middle, right, sentence);

			if(status == 0)

			{

				if(strlen(sentence) > 3)

				{

					sentIdx++;

					fprintf(sentOut, "%d\t%d\t%s\n", i, sentIdx, sentence);

					printf("%s\n", sentence);

				}

			}



			if(status == 1)

			{



			//	printf("L: %s\n", left);

			//	printf("M: %s\n", middle);

			//	printf("R: %s\n", right);

				



				if(!IsSameWord(left, Verb) && !IsSameWord(right, Verb))

				{

					fprintf(tupleTextOut, "%d\t%d\t%s\t%s\t%s\n", i, sentIdx, left, middle, right);

					int lIdx, rIdx, mIdx;

					bool found = false;



					for(j=0;j<nounIdx;j++)

					{

						if(IsSameWord(left, &(nouns[j][0])))

						{

							lIdx = j;

							found = true;

						}

					}



					if(!found)

					{

						sprintf(&(nouns[nounIdx][0]), "%s", left);

						lIdx = nounIdx;

						nounIdx++;

					}



					found = false;

					for(j=0;j<nounIdx;j++)

					{

						if(IsSameWord(right, &(nouns[j][0])))

						{

							rIdx = j;

							found = true;

						}

					}



					if(!found)

					{

						sprintf(&(nouns[nounIdx][0]), "%s", right);

						rIdx = nounIdx;

						nounIdx++;

					}



					found = false;

					for(j=0;j<relationIdx;j++)

					{

						if(IsSameWord(middle, relations[j]))

						{

							mIdx = j;

							found = true;

						}

					}



					if(!found)

					{

						sprintf(relations[relationIdx], "%s", middle);

						mIdx = relationIdx;

						relationIdx++;

					}



					nounCt[lIdx]++;

					nounCt[rIdx]++;

					relationCt[mIdx]++;



					fprintf(tupleOut, "%d\t%d\t%d\t%d\t%d\n", i, sentIdx, lIdx, mIdx, rIdx);

				}

			}

		}



		fclose(inTuple);

	}



	fclose(sentOut);

	fclose(tupleOut);

	fclose(tupleTextOut);

	*/



	FILE *out;

	sprintf(name, "%sObjectList_%d.txt", m_BaseName, m_NumScenes);

	out = fopen(name, "w");

	for(i=0;i<nounIdx;i++)

		fprintf(out, "%d\t%d\t%s\n", i, nounCt[i], nouns[i]);



	fclose(out);



	sprintf(name, "%sRelationList_%d.txt", m_BaseName, m_NumScenes);

	out = fopen(name, "w");

	for(i=0;i<relationIdx;i++)

		fprintf(out, "%d\t%d\t%s\n", i, relationCt[i], relations[i]);



	fclose(out);

		



}



void CClipArt::SaveSeedScenesTxt(std::vector<std::vector<int> > clipArtObjectIdx, std::vector<std::vector<int> > clipArtTypeIdx, 

							std::vector<std::vector<int> > clipArtX, std::vector<std::vector<int> > clipArtY, 

							std::vector<std::vector<int> > clipArtZ, std::vector<std::vector<int> > clipArtFlip, int numScenes)

{

	int i, j, k;

	FILE *out;

	char name[1024];

	int notUsed = -10000;



	char (*prefix)[256] = new char [m_NumTypes][256];

	sprintf(prefix[0], "s");

	sprintf(prefix[1], "p");

	sprintf(prefix[2], "hb0");

	sprintf(prefix[3], "hb1");

	sprintf(prefix[4], "a");

	sprintf(prefix[5], "c");

	sprintf(prefix[6], "e");

	sprintf(prefix[7], "t");



	int numSentences = 1002;

	

	char (*seedSent)[1024] = new char [numSentences][1024];

	sprintf(name, "%sseed_sentences_1002.txt", m_BaseName);

	printf("Opening %s\n", name);

	FILE *in = fopen(name, "r");



	for(i=0;i<numSentences;i++)

	{

		int j = 0;

		char cx = 2;

		while(cx != '\n')

		{

			fscanf(in, "%c", &cx);

			if(cx != '\'' && cx != '"')

			{

				seedSent[i][j] = cx;

				j++;

			}

		}

		seedSent[i][j] = 0;

	}

	

	fclose(in);

	printf("dfgdfg\n");



	char (*sent)[1024] = new char [numSentences][1024];

	sprintf(name, "%sSentences_1002.txt", m_BaseName);

	printf("Opening %s\n", name);

	in = fopen(name, "r");



	for(i=0;i<numSentences;i++)

	{

		int j = 0;

		char cx = 2;

		while(cx != '\n')

		{

			fscanf(in, "%c", &cx);



			if(cx != '\'' && cx != '"')

			{

				sent[i][j] = cx;

				j++;

			}

		}

		sent[i][j] = 0;

	}

	

	fclose(in);





	sprintf(name, "%sSceneData_%d.txt", m_BaseName, numScenes);

	out = fopen(name, "w");



	fprintf(out, "%d\n", numScenes);



	float depthScale[3];

	depthScale[0] = 1.f;

	depthScale[1] = 0.7f;

	depthScale[2] = 0.49f;



	for(k=0;k<numSentences;k++)

	{

		int idx = -1;

		bool found = false;



		for(i=0;i<numSentences;i++)

		{

			int match = true;

			int l = 0;



			for(j=0;j<strlen(sent[k]) + 1;j++)

			{

				if(sent[k][j] != seedSent[i][j])

					match = false;

			}



			if(match == true)

			{

				found = true;

				idx = i;

			}



		}



		if(!found)

			printf("Didn't find match %d\n", k);



		if(found)

		{

			int numClipArt = 0;

			for(j=0;j<clipArtTypeIdx[idx].size();j++)

			{

				if(clipArtX[idx][j] > notUsed)

					numClipArt++;

			}



			fprintf(out, "%d\t%d\n", k, numClipArt);



			for(j=0;j<clipArtTypeIdx[idx].size();j++)

			{

				if(clipArtX[idx][j] > notUsed)

				{

					fprintf(out, "%s_%ds.png\t%d\t%d\t", prefix[clipArtTypeIdx[idx][j]], clipArtObjectIdx[idx][j], clipArtTypeIdx[idx][j], clipArtObjectIdx[idx][j]);

					fprintf(out, "%d\t%d\t\%d\t%d\n", clipArtX[idx][j], clipArtY[idx][j], clipArtZ[idx][j], clipArtFlip[idx][j]);

				}

			}

		}

	}



	fclose(out);

}


template< typename T >
T subvector(T v, int start, int end)
{
	return T(v.begin() + start, v.begin() + end);
}


int main(int argc, char* argv[])

{



	if(argc != 6)

	{	

		printf("Format:  ClipArtRender <input file> <output basename> <render flag>\n");

		return 0;

	}



	char inName[1024];

	strcpy(inName, argv[1]);

	

	char baseName[1024];

	strcpy(baseName, argv[2]);



	char sentenceName[1024];

	sprintf(sentenceName, "%s_sentences.txt", baseName);



	char commentName[1024];

	sprintf(commentName, "%s_comments.txt", baseName);



	FILE *in;

	FILE *out;

	FILE *outComment;



	CClipArt m_ClipArt;



	printf("Initializing\n");

	m_ClipArt.Init();



//	m_ClipArt.SaveClipArtSingles();

//	return 0;



	bool doRender = false;

	if(atoi(argv[3]) > 0)

		doRender = true;


	if(doRender)

	{
		printf("Main: Loading GMM\n");
		m_ClipArt.ReadGMMParamters();

		printf("Main: Parsing Tuples\n");
		m_ClipArt.ParseTuples();


		printf("Main: Computing MI\n");
		m_ClipArt.ComputeNounTupleMI();

		printf("Main: Computing mean tuple attributes\n");
		m_ClipArt.ComputeMeanTupleAttribute();

		printf("Main: Loading Mean Attributes\n");
		m_ClipArt.LoadMeanAttributes();

	//	return 0;

	}



//	m_ClipArt.DisplayAbsolutePosition();

//	m_ClipArt.DisplayExpressions();

//	m_ClipArt.DisplayPoses();

//	m_ClipArt.DisplayRelations();

//	return 0;


	strcpy(m_ClipArt.prefix,argv[1]);
	
	int start = atoi(argv[4]);

	int end = atoi(argv[5]);



	if(doRender)

	{

		printf("Rendering Scenes\n");

	//	m_ClipArt.SaveAverageAttributes();



		m_ClipArt.LoadNounMap();

		while(true)
		{
			m_ClipArt.RenderScenes();
			usleep(2000);
		}

		return 0;

	}



	printf("Opening %s\n", inName);

	in = fopen(inName, "r");



	printf("Opening %s\n", commentName);

	outComment = fopen(commentName, "w");



	if(in == NULL)

	{

		printf("Couldn't open file %s\n", inName);

		return 0;

	}




	int ct;

	int idx = 0;

	int hitSize = 3;

	vt::wstring wstr2(320);

	int i, j, k, a, b, r, c;

	char ch;





	std::vector<std::vector<int> > clipArtObjectIdxAll;

	std::vector<std::vector<int> > clipArtTypeIdxAll;

	std::vector<std::vector<int> > clipArtXAll;

	std::vector<std::vector<int> > clipArtYAll;

	std::vector<std::vector<int> > clipArtZAll;

	std::vector<std::vector<int> > clipArtFlipAll;

	std::vector<std::vector<int> > clipArtWAll;

	std::vector<std::vector<int> > clipArtHAll;



	clipArtObjectIdxAll.resize(20000);

	clipArtTypeIdxAll.resize(20000);

	clipArtXAll.resize(20000);

	clipArtYAll.resize(20000);

	clipArtZAll.resize(20000);

	clipArtFlipAll.resize(20000);

	clipArtWAll.resize(20000);

	clipArtHAll.resize(20000);

	int numClipArt = 28;



	printf("Reading Scenes\n");

	int total = 0;
	fscanf(in, "%d,", &total);
	int index = 0;
	while(fscanf(in, "%d %d,", &index, &ct) != EOF)

	{
		printf("Reading scene %d, with index %d\n", idx,index);
		printf("There are '%d objects\n", ct);

		char (*imgNames)[1024] = new char [ct][1024];

		int *clipArtObjectIdx = new int [ct];

		int *clipArtTypeIdx = new int [ct];

		int *clipArtX = new int [ct];

		int *clipArtY = new int [ct];

		int *clipArtZ = new int [ct];

		int *clipArtFlip = new int [ct];

		int (*clipArtW)[4] = new int [ct][4];

		int (*clipArtH)[4] = new int [ct][4];

		int (*clipArtC)[7] = new int [ct][7];


		numClipArt = ct;
		clipArtObjectIdxAll[idx].resize(numClipArt);

		clipArtTypeIdxAll[idx].resize(numClipArt);

		clipArtXAll[idx].resize(numClipArt);

		clipArtYAll[idx].resize(numClipArt);

		clipArtZAll[idx].resize(numClipArt);

		clipArtFlipAll[idx].resize(numClipArt);

		clipArtWAll[idx].resize(numClipArt);

		clipArtHAll[idx].resize(numClipArt);



		for(i=0;i<ct;i++)

		{

			j = 0;
			fscanf(in, "%s", imgNames[i]);
			printf("%s\n", imgNames[i]);

			/*fscanf(in, "%c", &ch);

			while(ch != ',')

			{

				imgNames[i][j] = ch;

				fscanf(in, "%c", &ch);;

				j++;

			}

			imgNames[i][j] = 0;
			*/


		//	fscanf(in, "%d,", &a);
			fscanf(in, "%d,", &(clipArtTypeIdx[i]));

			fscanf(in, "%d,", &(clipArtObjectIdx[i]));




			fscanf(in, "%d,", &(clipArtX[i]));

			fscanf(in, "%d,", &(clipArtY[i]));

			fscanf(in, "%d,", &(clipArtZ[i]));

			fscanf(in, "%d,", &(clipArtFlip[i]));

			for(j=0;j<4;j++)

			//	fscanf(in, "%d,", &(clipArtW[i][j]));
			clipArtW[i][j] = 0;

			for(j=0;j<4;j++)

			//	fscanf(in, "%d,", &(clipArtH[i][j]));
			clipArtH[i][j] = 0;


			for(j=0;j<7;j++)

			//	fscanf(in, "%d,", &(clipArtC[i][j]));
			clipArtC[i][j] = 0;


		}



		for(j=0;j<ct;j++)

		{

			if(clipArtZ[j] >= 0 && clipArtZ[j] < 3)

			{

				clipArtObjectIdxAll[idx][j] = clipArtObjectIdx[j];

				clipArtTypeIdxAll[idx][j] = clipArtTypeIdx[j];

				clipArtXAll[idx][j] = clipArtX[j];

				clipArtYAll[idx][j] = clipArtY[j];

				clipArtZAll[idx][j] = clipArtZ[j];

				clipArtFlipAll[idx][j] = clipArtFlip[j];

			}

			else

			{

				clipArtXAll[idx][j] = -10000;

				clipArtX[j] = -10000;

				clipArtObjectIdxAll[idx][j] = 0;

				clipArtTypeIdxAll[idx][j] = 0;

			}

		}



		// remove comments
		
		if(idx%hitSize == hitSize - 1 && false)

		{

			fprintf(outComment, "%d\t", idx/hitSize);

			fscanf(in, "%c", &ch);

		//	printf("%c", ch);

			fprintf(outComment, "%c", ch);

			fscanf(in, "%c", &ch);

			fprintf(outComment, "%c", ch);

			bool wasIn = false;



			while(ch != '*')

			{

		//		printf("%c", ch);

				fscanf(in, "%c", &ch);

				fprintf(outComment, "%c", ch);

				wasIn = true;

			}



			if(wasIn)

			{

		//		printf("\n");

			}



			fprintf(outComment, "\n");



			fscanf(in, "%c", &ch);



			if(ch != '\n')

			{

				printf("\n********* ERROR: Didn't find newline %d********\n", numClipArt);

				for(j=0;j<numClipArt;j++)

					clipArtXAll[idx][j] = -100000;

				for(j=0;j<numClipArt;j++)

					clipArtXAll[idx-1][j] = -100000;

				for(j=0;j<numClipArt;j++)

					clipArtXAll[idx-2][j] = -100000;



				for(j=0;j<numClipArt;j++)

					clipArtX[j] = -100000;

			}



			while(ch != '\n')

			{

				fscanf(in, "%c", &ch);

			}

		}



		idx++;



		delete [] imgNames;

		delete [] clipArtObjectIdx;

		delete [] clipArtTypeIdx;

		delete [] clipArtX;

		delete [] clipArtY;

		delete [] clipArtZ;

		delete [] clipArtFlip;

		delete [] clipArtW;

		delete [] clipArtH;

		delete [] clipArtC;

	}



	printf("Number Scenes = %d\n", idx);
	printf("Fixing dog cat issue\n");

	// Fix issue with the dog and cat being initially flipped the wrong direction...
	/*
	for(i=0;i<idx;i++)

	{

		printf("%d\n", clipArtTypeIdxAll[i].size());



		for(j=0;j<m_ClipArt.m_NumClipArtDisplayed;j++)

			if(clipArtXAll[i][j] >= 0)

		{

			//printf("%d %d\n", clipArtTypeIdxAll[i][j], clipArtObjectIdxAll[i][j]);

			int idx0 = m_ClipArt.m_MapInstance[clipArtTypeIdxAll[i][j]][clipArtObjectIdxAll[i][j]];



			// Cat or Dog?

			if(idx0 == 21 || idx0 == 22)

			{

				clipArtFlipAll[i][j] = (clipArtFlipAll[i][j] + 1)%2;

			}

		}

	}
	*/


	m_ClipArt.SaveSceneTuples();
	//m_ClipArt.SaveScenesTxt(clipArtObjectIdxAll, clipArtTypeIdxAll, clipArtXAll, clipArtYAll, clipArtZAll, clipArtFlipAll, idx);




	printf("Number Scenes = %d\n", idx);

	m_ClipArt.SaveFeatures(subvector(clipArtObjectIdxAll, start, end), subvector(clipArtTypeIdxAll, start, end), subvector(clipArtXAll, start, end), subvector(clipArtYAll, start, end), subvector(clipArtZAll, start, end), subvector(clipArtFlipAll, start, end), end - start);
	m_ClipArt.SaveAverageAttributes();



	if (doRender || true)

	{
		printf("Main: Loading GMM\n");
		m_ClipArt.ReadGMMParamters();

		printf("Main: Parsing Tuples\n");
		m_ClipArt.ParseTuples();


		printf("Main: Computing MI\n");
		m_ClipArt.ComputeNounTupleMI();

		printf("Main: Computing mean tuple attributes\n");
		m_ClipArt.ComputeMeanTupleAttribute();

		//	printf("Main: Loading Mean Attributes\n");
		//	m_ClipArt.LoadMeanAttributes();
		//	return 0;

	}
	


	m_ClipArt.ScoreCRF(start, end, clipArtObjectIdxAll, clipArtTypeIdxAll, clipArtXAll, clipArtYAll, clipArtZAll, clipArtFlipAll, idx);


	printf("Number Scenes = %d\n", idx);

	fclose(in);

	fclose(outComment);

	

	return 0;

}



