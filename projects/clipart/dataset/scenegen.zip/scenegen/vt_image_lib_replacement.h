#include <cstring>
namespace vt
{
	class RGBAPix
	{
	public:
		int r,g,b,a;
		RGBAPix()
		{
			r=0;g=0;b=0;a=0;
		}
	};
	class CRGBAImg
	{
	public:
		RGBAPix* img;
		int imgx;
		int imgy;
		CRGBAImg()
		{
			imgx=0;imgy=0;
			img=NULL;
		};
		void Create(int x,int y)
		{
			if(img!=NULL)
				delete img;
			img=new RGBAPix[x*y];
			imgx=x;
			imgy=y;
		};
		void Fill(RGBAPix p)
		{
			for(int i=0;i<imgx*imgy;i++)
				img[i]=p;
		}
		RGBAPix& Pix(int x,int y)
		{
			return img[y*imgx+x];
		};
		int Width()
		{
			return imgx;
		};
		int Height()
		{
			return imgy;
		};
		void Clear()
		{
			RGBAPix pix;
			pix.r=0;
			pix.g=0;
			pix.b=0;
			pix.a=0;
			Fill(pix);
		};
		~CRGBAImg()
		{
			if(img!=NULL)
				delete img;
		};
	};
	class Matrix
	{
	public:
		float* img;
		int imgx;
		int imgy;
		Matrix()
		{
			imgx=0;imgy=0;
			img=NULL;
		};
		void Create(int x,int y)
		{
			if(img!=NULL)
				delete img;
			img=new float[x*y];
			imgx=x;
			imgy=y;
		};
		void Fill(float p)
		{
			for(int i=0;i<imgx*imgy;i++)
				img[i]=p;
		}
		float& Pix(int x,int y)
		{
			return img[y*imgx+x];
		};
		int Width()
		{
			return imgx;
		};
		int Height()
		{
			return imgy;
		};
		void Clear()
		{
			float pix=0;
			Fill(pix);
		};
		~Matrix()
		{
			if(img!=NULL)
				delete img;
		};
		void CopyTo(Matrix& target)
		{
			target.Create(imgx,imgy);
			for(int i=0;i<imgx*imgy;i++)
				target.img[i]=img[i];
		}
	};
	class wstring
	{
	public:
		wchar_t* wstr_val;
		wstring(int x)
		{
			wstr_val=new wchar_t[x];
		}
		~wstring()
		{
			if(wstr_val!=NULL)
				delete wstr_val;
		}
		void format(const wchar_t* fstr)
		{
			swprintf(wstr_val,10000,fstr);
		}
		void format(const wchar_t* fstr,const char* str1)
		{
			swprintf(wstr_val,10000,fstr,str1);
		}
		void format(const wchar_t* fstr,const char* str1,const int num1)
		{
			swprintf(wstr_val,10000,fstr,str1,num1);
		}
		void format(const wchar_t* fstr,const char* str1,const int num1,const int num2)
		{
			swprintf(wstr_val,10000,fstr,str1,num1,num2);
		}
		void format(const wchar_t* fstr,const char* str1,const int num1,const int num2,const int num3)
		{
			swprintf(wstr_val,10000,fstr,str1,num1,num2,num3);
		}
	};
	
	void VtSaveImage(wstring fname,CRGBAImg image)
	{
		
	};
	void VtLoadImage(wstring fname,CRGBAImg image)
	{
	};
	void VtDrawCircle(CRGBAImg outImg, float x, float y, float r, RGBAPix pix)
	{
		for(float theta=0;theta<2*3.1415927;theta=theta+0.005)
		{
			int indx=x+r*sin(theta);
			int indy=y+r*cos(theta);
			
			if(indx>=0 && indy>=0 && indx<outImg.imgx && indy<outImg.imgy)
			{
				outImg.Pix(indx,indy)=pix;
			}
		}
	};
};