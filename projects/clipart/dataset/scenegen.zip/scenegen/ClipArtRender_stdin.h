#pragma once
#define _CRT_SECURE_NO_WARNINGS

#include <cstdlib>
#include <cstring>
#include <cmath>
#include <vector>
#include "vt_image_lib_replacement.h"
using namespace vt;

const int NUM_GM_REL=24;
const int NUM_GM_SPAT=9;

const int NUM_OBJ=58;

const int NUM_NOUN=1133;
const int NUM_REL=2379;

const int CANVAS_WIDTH=500;
const int CANVAS_HEIGHT=400;




class CClipArt
{
public:


	char prefix[1000];
	char m_InstNames[100][100]; //object names
	int m_NumNouns;
	int m_RelativeSpatialIdx;
	int m_RelativeSpatialFlipIdx;
	int m_RelativeDepthIdx;
	int m_HandIdx;
	int m_ClothingIdx;
	int m_TestingIdx;
	int m_NumAttributes;
	int m_AbsoluteSpatialIdx;
	int m_NumRelations;
	int m_NumExpressions;
	int m_NumPoses;
	int m_NumTypes;
	int m_PoseIdx;
	int m_NumInstanceObj; // Prolly NUM_OBJ
	int m_ExpressionIdx;
	int m_NumPersonAttrs;
	int m_NumClothing;
	int m_NumScenes;
	int m_CoOccurrenceIdx;
	int m_TypeCt[9];
	std::vector< std::vector< std::vector<int> > > m_ClipArtW;
	std::vector< std::vector< std::vector<int> > > m_ClipArtH;
	std::vector< std::vector< std::vector<int> > > m_ClipArtC;
	int (*m_HeadPos)[7][2]; //per person per pose
	int (*m_HandPos)[2][7][2]; //per person per pose

	std::vector<std::vector<std::vector<int> > > m_Tuple;

	float m_ScaleFactor;

	int clipArtTypeIdx[NUM_OBJ];
	int clipArtObjectIdx[NUM_OBJ];

	void LoadTuples();
	std::vector< std::vector<float> > m_LeftAttr;
	std::vector< std::vector<float> > m_RightAttr;
	std::vector< std::vector<float> > m_RelAttr; // I don't know what it does
	float *m_AverageAttributes;
	std::vector<int> m_RelMap;
	char m_BaseName[1000];
	float m_GMM_mean_RelFlip[NUM_GM_REL * 2];
	float m_GMM_std_RelFlip[NUM_GM_REL * 2];
	float (*m_GMM_mean_Spat)[2 * NUM_GM_SPAT];
	float (*m_GMM_std_Spat)[2 * NUM_GM_SPAT];
	float m_GMM_mean_Rel[NUM_GM_REL * 2];
	float m_GMM_std_Rel[NUM_GM_REL * 2];

	int* m_MapType;
	int* m_MapObject;

	std::vector<int> m_NounMap;
	std::vector<Matrix> m_PDFPrior;
	std::vector<Matrix> m_PDFPost;

	int m_NumDepth; //3
	int m_NumClipArtDisplayed; //6 or 8 or something
	int (*m_MapInstance)[35]; //type and index






	void AssignNames();
	void Init();
	void SaveClipArtSingles();
	void RenderScenes();
	void RenderScene(std::vector<int> clipArtTypeIdx, std::vector<int> clipArtObjectIdx, std::vector<int> clipArtX, std::vector<int> clipArtY, std::vector<int> clipArtZ,std::vector<int> clipArtFlip, vt::CRGBAImg &outImg);
	void ComputePDFs(float *attributes);
	
	void SaveAverageAttributes();
	void ComputeGMM(float (*)[2], int,int,float*,float*);
	void ComputeRelativePosition(int,int,int,int,int,float*,int);
	void ComputeGMMProbs(float*,float*,float*,float*,int);
	void ComputeGMMParameters(std::vector<std::vector<int> > clipArtObjectIdx, std::vector<std::vector<int> > clipArtTypeIdx,std::vector<std::vector<int> > clipArtX, std::vector<std::vector<int> > clipArtY,std::vector<std::vector<int> > clipArtZ, std::vector<std::vector<int> > clipArtFlip, int numScenes);
	void DisplayRelations();
	void DisplayExpressions();
	void DisplayPoses();
	void DisplayAbsolutePosition();
	void LoadAverageAttributes();
	void ReadGMMParamters();
	void LoadTestingTuples();
	void LoadNounMap();
	void ComputeMostCommonPrimarySecondaryNouns();
	void UpdateAttributesWithTuples(float *attributes, std::vector<std::vector<int> > tuples);
	float ScoreScene(std::vector<int> clipArtTypeIdx, std::vector<int> clipArtObjectIdx, std::vector<int> clipArtX, std::vector<int> clipArtY, std::vector<int> clipArtZ,std::vector<int> clipArtFlip, float *desiredAttributes);
	void SaveFeatures(std::vector<std::vector<int> > clipArtObjectIdx, std::vector<std::vector<int> > clipArtTypeIdx,std::vector<std::vector<int> > clipArtX, std::vector<std::vector<int> > clipArtY,std::vector<std::vector<int> > clipArtZ, std::vector<std::vector<int> > clipArtFlip, int numScenes);
	void ComputeAttributes(std::vector<int>, std::vector<int>, std::vector<int>, std::vector<int>, std::vector<int>, std::vector<int>, int, float*);
	void ComputeHeadPosition(int typeIdx, int objIdx, int x, int y, int z, int flip, int clothingIdx, int &hx, int &hy);
	void ScoreCRF(int start, int end, std::vector<std::vector<int> > clipArtObjectIdx, std::vector<std::vector<int> > clipArtTypeIdx,std::vector<std::vector<int> > clipArtX, std::vector<std::vector<int> > clipArtY,std::vector<std::vector<int> > clipArtZ, std::vector<std::vector<int> > clipArtFlip, int numScenes);
	void FixNaming();
	float GenerateScene(float *attributes, vt::CRGBAImg &outImg, char* dumpster, int scene_id);
	
	void DumpScene(std::vector<int> clipArtTypeIdx, std::vector<int> clipArtObjectIdx, std::vector<int> clipArtX, std::vector<int> clipArtY, std::vector<int> clipArtZ, std::vector<int> clipArtFlip, char* dumpster, int id);
	void SaveScenesTxt(std::vector<std::vector<int> > clipArtObjectIdx, std::vector<std::vector<int> > clipArtTypeIdx, std::vector<std::vector<int> > clipArtX, std::vector<std::vector<int> > clipArtY, std::vector<std::vector<int> > clipArtZ, std::vector<std::vector<int> > clipArtFlip, int numScenes);
	void SaveSceneTuples();
	int ScanTuple(FILE *in, char *left, char *middle, char *right, char *sentence);
	bool IsSameWord(char *word0, char *word1);
	void ParseTuples();
	void ComputeNounTupleMI();
	void ComputeMeanTupleAttribute();
	void LoadMeanAttributes();
	void SaveSeedScenesTxt(std::vector<std::vector<int> > clipArtObjectIdx, std::vector<std::vector<int> > clipArtTypeIdx, std::vector<std::vector<int> > clipArtX, std::vector<std::vector<int> > clipArtY, std::vector<std::vector<int> > clipArtZ, std::vector<std::vector<int> > clipArtFlip, int numScenes);
};


