import string
import random
import os
import subprocess
import time
import json

DEVNULL= open(os.devnull,"w")

def id_generator(size=20, chars=string.ascii_uppercase + string.ascii_lowercase + string.digits):
	return ''.join(random.choice(chars) for _ in range(size))

def check_table(x,table):
	if not x in table:
		return -1;
	else:
		return table[x];

def nounmap(tuple,noun_map,rel_map):
	return (check_table(tuple[0],noun_map),check_table(tuple[1],rel_map),check_table(tuple[2],noun_map));

class scenegen:
	noun_map=dict();
	rel_map=dict();
	daemon=[];
	def load_noun_maps(self):
		#map tuples into numbers
		self.noun_map=dict();
		f=open('./scenegen/NounsMap.txt','r');
		for line in f:
			s=line.split('\t');
			self.noun_map[s[2].rstrip('\n')]=int(s[0]);
			if s[2].rstrip('\n')=="":
				self.noun_map[None]=int(s[0]);
		
		self.rel_map=dict();
		f=open('./scenegen/RelationsMap.txt','r');
		for line in f:
			s=line.split('\t');
			self.rel_map[s[2].rstrip('\n')]=int(s[0]);
			if s[2].rstrip('\n')=="":
				self.rel_map[None]=int(s[0]);
	
	def launch_daemon(self):
		self.daemon=subprocess.Popen("cd ./scenegen/;./render_online 0 0 1 0 1", shell=True,stdout=DEVNULL,stderr=subprocess.PIPE,stdin=subprocess.PIPE);
		while True:
			line = self.daemon.stderr.readline().rstrip('\n');
			if line=="READY":
				break;
			time.sleep(1);
	
	def stop_daemon(self):
		self.daemon.kill();
	
	def scenegen(self,tuples,raw=False):
		tuples_mapped=[nounmap(i,self.noun_map,self.rel_map) for i in tuples];
		for i in tuples_mapped:
			self.daemon.stdin.write("%d %d %d\n"%(i[0],i[1],i[2]));
		
		self.daemon.stdin.write("END\n");
		
		status=1;
		ntotal_objects=0;
		ncurrent_object=0;
		scene=dict();
		
		while True:
			line = self.daemon.stderr.readline().rstrip('\n');
			if line=="BEGIN":
				break;
		
		raw_data='';
		while True:
			line = self.daemon.stderr.readline().rstrip('\n');
			if line=="END":
				break;
			line=line.rstrip('\n');
			raw_data=raw_data+line+'\n';
			s=line.split('\t')
			if len(s)==0 or s[0]=="":
				continue;
			
			if status==1:
				scene=dict();
				scene["objects"]=list();
				scene["meta"]=dict();
				ntotal_objects=int(s[1]);
				ncurrent_object=0;
				scene["meta"]["id"]=int(s[0]);
				if ntotal_objects>0:
					status=2;
			
			elif status==2:
				object=dict();
				object['png']=s[0];
				object['category']=int(s[1]);
				object['attribute']=int(s[2]);
				object['x']=int(s[3]);
				object['y']=int(s[4]);
				object['z']=int(s[5]);
				object['flip']=int(s[6]);
				scene["objects"].append(object);
				ncurrent_object=ncurrent_object+1;
				if ntotal_objects==ncurrent_object:
					status=1;
		
		scene['tuple_ids']=tuples_mapped;
		scene['raw']=raw_data;
		return scene;


def read_tuples(fname_tuples):
	tuples=list();
	f=open(fname_tuples,"r");
	for line in f:
		s=line.rstrip('\n').split("\t");
		while len(tuples)<=int(s[0]):
			tuples.append(list());
		
		tuples[int(s[0])].append((s[1],s[2],s[3]));
	
	f.close();
	return tuples;


if __name__ == "__main__":
	handler=scenegen();
		
	print('Initializing daemon');
	handler.launch_daemon();
	handler.load_noun_maps();
	print('Daemon initialized\n');
	time1 = time.time();
	tuples=[["mike","kick","ball"],['jenny','fly','kite'],['jenny','watch','mike']];
	print('Original Tuples')
	print(tuples);
	print('');
	s=handler.scenegen(tuples);
	time2 = time.time();
	print('Tuples encoded as');
	print(s['tuple_ids']);
	print('');
	print('Generated scene in raw format')
	print(s['raw'])
	print('');
	print('Generated scene in json format')
	print(json.dumps(s))
	print('');
	print('Scene generation took %0.3f ms' % ((time2-time1)*1000.0))
	handler.stop_daemon()