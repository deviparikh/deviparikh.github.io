Clipart scene generation model learned using the AbstractScenes_v1.1 dataset. Please consider citing the following paper when using this model for your research.

	[1] C. L. Zitnick, D. Parikh, and L. Vanderwende."Learning the Visual Interpretation of Sentences". ICCV 2013.

Requirements:

	Linux with g++ (tested on Ubuntu 14.04 with g++-4.8.4)
	Python 2.6+ (tested on Python 2.7)

Usage:

	#Unpackage code
	unzip scenegen.zip
	# Build scene generation command line daemon, which is a C program.
	cd scenegen/;./build.sh; cd ..
	# Run scene generation python wrapper for a demo. 
	# Note that you can also use it as a python package.
	# Read scenegen_stdin_wrapper.py for detailed usage.
	python scenegen_stdin_wrapper.py


Example output:

	Initializing daemon
	Daemon initialized

	Original Tuples
	[['mike', 'kick', 'ball'], ['jenny', 'fly', 'kite'], ['jenny', 'watch', 'mike']]

	Tuples encoded as
	[(11, 6, 1), (10, 45, 42), (10, 15, 11)]

	Generated scene in raw format
	0       6
	hb0_11s.png     2       11      110     270     1       0
	t_4s.png        7       4       200     270     1       0
	s_3s.png        0       3       70      70      1       1
	hb1_32s.png     3       32      320     270     0       1
	t_13s.png       7       13      280     110     1       1
	s_2s.png        0       2       140     70      1       1



	Generated scene in json format
	{"tuple_ids": [[11, 6, 1], [10, 45, 42], [10, 15, 11]], "objects": [{"category": 2, "attribute": 11, "flip": 0, "y": 270, "x": 110, "z": 1, "png": "hb0_11s.png"}, {"category": 7, "attribute": 4, "flip": 0, "y": 270, "x": 200, "z": 1, "png": "t_4s.png"}, {"category": 0, "attribute": 3, "flip": 1, "y": 70, "x": 70, "z": 1, "png": "s_3s.png"}, {"category": 3, "attribute": 32, "flip": 1, "y": 270, "x": 320, "z": 0, "png": "hb1_32s.png"}, {"category": 7, "attribute": 13, "flip": 1, "y": 110, "x": 280, "z": 1, "png": "t_13s.png"}, {"category": 0, "attribute": 2, "flip": 1, "y": 70, "x": 140, "z": 1, "png": "s_2s.png"}], "meta": {"id": 0}, "raw": "0\t6\nhb0_11s.png\t2\t11\t110\t270\t1\t0\nt_4s.png\t7\t4\t200\t270\t1\t0\ns_3s.png\t0\t3\t70\t70\t1\t1\nhb1_32s.png\t3\t32\t320\t270\t0\t1\nt_13s.png\t7\t13\t280\t110\t1\t1\ns_2s.png\t0\t2\t140\t70\t1\t1\n\n"}

	Scene generation took 6302.640 ms

Previewing generated scene:
	
	Open render.html using a web browser. Copy and paste the json format data into the textbox, then click the "Render Scene" button to view the generated scene in the web browser. The clipart images are hosted on vision.ece.vt.edu server so make sure your computer is online.
	
	The raw format follows the data format in AbstractScenes_v1.1. So you can also render the raw format using SceneRenderer.exe in AbstractScenes_v1.1.